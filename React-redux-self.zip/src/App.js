import React from "react";
import Counter from "./components/Counter";
import CounterClass from "./components/CounterClass";
function App() {
  return (
    <div className="container">
     <h1>React Redux using function Hooks</h1>
     <Counter/>     
     
     <h1>React Redux using Class</h1>
     <CounterClass/>
    </div>
  );
}

export default App;
