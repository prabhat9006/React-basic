import React, { Component } from 'react';
import { increment, decrement } from "../actions/index";
import { connect } from 'react-redux';

const mapStateToProps = (props) => {
    return {
        counterValue: props.modifiedCounterValue
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        increment: () => dispatch(increment()),
        decrement: () => dispatch(decrement())
    }
}
class CounterClass extends Component {
    render() {
        return (
            <div className="container">
                <h1>Counter App</h1>
                counterValue: {this.props.counterValue}<br />
                <button type="button" className="btn btn-primary" onClick={this.props.increment}>Increment</button><br /><br />
                <button type="button" className="btn btn-lg btn-primary" onClick={this.props.decrement}>Decrement</button>
            </div>
        );
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(CounterClass);