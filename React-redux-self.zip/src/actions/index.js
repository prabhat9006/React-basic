export  const increment = () => {
    return{
        type: "INCREMEMT"
    }
}

export  const decrement = () => {
    return{
        type: "DECREMENT"
    }
}