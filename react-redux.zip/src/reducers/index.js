import modifiedCounterValue from "./updown";
import { combineReducers } from "redux";

const rootReducer = combineReducers({
    modifiedCounterValue
})

export default rootReducer;