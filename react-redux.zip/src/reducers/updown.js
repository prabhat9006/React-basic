const initiaValue = 0;

const modifiedCounterValue = (state = initiaValue, action) => {
    switch (action.type) {

        case "INCREMEMT":
         return state + 1;

        case "DECREMENT":
        return state - 1;
        default:
            return state;

    }

}

export default modifiedCounterValue;