import React from "react";
import { increment, decrement } from "../actions/index";
import { useSelector, useDispatch } from "react-redux";
 const Counter = ()=> {
   const counterValue = useSelector((state)=> state.modifiedCounterValue);
    const dispatch = useDispatch();
    return (
        <div className="container">
            <h1>Counter App</h1>
            counterValue: {counterValue}<br/>
            <button type="button" className="btn btn-primary"  onClick={()=> dispatch(increment())}>Increment</button><br/><br/>
            <button type="button" className="btn btn-lg btn-primary" onClick={()=> dispatch(decrement())}>Decrement</button>
        </div>
    );
}

export default Counter;