import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import ProjectTitle from "./component/projectTitle";
import ProductList from "./component/productList";
import ProductItemDetails from "./component/ProductItemDetails";
import { Home } from "./component/Home";
import "../src/CSS_Files/style.css"
function App() {
  return (
    <div className="container App">
      <BrowserRouter>
        <ProjectTitle />
        <Routes>
          <Route path="/" element={<Home/>}></Route>
          <Route path="/productList" element={<ProductList/>}></Route>
          <Route path="/productItemDetails" element={<ProductItemDetails/>}></Route>
          <Route path="/productItemDetails/:id" element={<ProductItemDetails/>}></Route>
          <Route>404 Not Found!</Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;