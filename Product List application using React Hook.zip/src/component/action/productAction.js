import axios from "axios";
const url2 = "http://localhost:3002/productList";
const url = "http://localhost:3002/productList/?id=";


export const fetchProductList = () => {
  return dispatch => {
      axios.get(url2).then(response => {
      dispatch({
          type: "DISPLAY_PRODUCT_RECORDS",
          payload: response.data
      });
    });
  };
};
export const fetchSelectedProduct = (id) => {
  return dispatch => {
      axios.get(url+`${id}`).then(response => {
      dispatch({
          type: "DISPLAY_SELECTED_PRODUCT_RECORD",
          payload: response.data
      });
    });
  };
};
