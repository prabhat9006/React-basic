import React from 'react';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchSelectedProduct } from './action/productAction';
import { useParams } from "react-router-dom";
const url = "http://localhost:3002/productList/?id=";



const ProductItemDetails = () => {

    let { id } = useParams();
    if (!id) id = "1";
    const [secltedProductList, setSelectedProductList] = useState([]);

    const dispatch = useDispatch()

    const selectedProductRes = useSelector((state) => state.productData);
    useEffect(() => {
        setSelectedProductList(selectedProductRes.selectedProductRecord);
    }, [selectedProductRes])

    useEffect(() => {
        getSelectedProduct(id)
    }, [])
    const getSelectedProduct = (id) => {
        dispatch(fetchSelectedProduct(id));
    }
    return (
        <div>
            {!secltedProductList ? <h1>No Product Available !!!</h1> :
                <div>
                    {
                        secltedProductList.map((myvariables, id) => (
                            <div className="ui placeholder product-title segment" key={id + 1}>
                                <div className="ui two column stackable center aligned grid">
                                    <div className="ui vertical divider">AND</div>
                                    <div className="middle aligned row">
                                        <div className="column lp">
                                            <img className="ui fluid image" src={myvariables.image} />
                                        </div>
                                        <div className="column rp">
                                            <h1>{myvariables.title}</h1>
                                            <h2>
                                                <a className="ui teal tag label">${myvariables.price}</a>
                                            </h2>
                                            <h3 className="ui brown block header">{myvariables.category}</h3>
                                            <p>{myvariables.description}</p>
                                            <div className="ui vertical animated button" tabIndex="0">
                                                <div className="hidden content">
                                                    <i className="shop icon"></i>
                                                </div>
                                                <div className="visible content">Add to Cart</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))

                    }


                </div>
            }
        </div>
    );
}

export default ProductItemDetails;