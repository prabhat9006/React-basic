
const productData = (state = {}, action) => {

    switch (action.type) {
        case 'DISPLAY_PRODUCT_RECORDS':
            return { ...state, productListRecord: action.payload }
        case 'DISPLAY_SELECTED_PRODUCT_RECORD':
            return { ...state, selectedProductRecord: action.payload}
        default:
            return state;

    }
}
export default productData;