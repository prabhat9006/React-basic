import productData from "./productData";

import {combineReducers} from "redux";


const rootReducer = combineReducers({
   productData
})
export default rootReducer;