import React from 'react';
import { Link } from "react-router-dom";
import { fetchProductList } from './action/productAction';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';


const ProductList = () => {
    const dispatch = useDispatch();
    const productLists = useSelector((state) => state.productData);
    const [productList, setproductList] = useState([]);
    useEffect(() => {
        setproductList(productLists.productListRecord);
    }, [productLists])


    useEffect(() => {
        saveProductId()
    }, [])

    const saveProductId = () => {
        dispatch(fetchProductList());
    }
    return (
        <div>
            {!productList ? <h1>No CourseList Available !!!</h1> :
                <div className="ui grid container">
                            {
                                productList.map((myvariables, id) => (
                                   
                                    <div className="four wide column" key={id}>
                                    <Link to={`/productItemDetails/${myvariables.id}`}>
                                      <div className="ui link cards">
                                        <div className="card">
                                          <div className="image">
                                            <img src={myvariables.image} alt="BigCo Inc. logo" />
                                          </div>
                                          <div className="content">
                                            <div className="header">{myvariables.title}</div>
                                            <div className="meta price">$ {myvariables.price}</div>
                                            <div className="meta">{myvariables.category}</div>
                                          </div>
                                        </div>
                                      </div>
                                    </Link>
                                  </div>
                                ))

                            }
                </div>
            }
        </div>
    );
}

export default ProductList;