// @flow
import * as React from 'react';

export class Home extends React.Component{
  render() {
    return (
      <div className="container">
         <h5>Product List Web ApplicationUsing React Hooks.</h5>
                <p>Create a Product List application using React Hooks. Follow the below steps to build the application:</p>

                <h5>1.Perform the state management using React Hooks (make use of useState() method).</h5>
                <h5>2.First page of application should display fooditems.</h5>
                <h5>3.First page of the application should contain the list of products.</h5>
                <h5>4.Make use of only functional components along with React Hooks syntax.</h5>
                <h5>5.Make the API call using ‘useEffect()’ method and Axios.</h5>
                <h5>6.Make use of Axios with saga to make an API call.</h5>
      </div>
    );
  };
};