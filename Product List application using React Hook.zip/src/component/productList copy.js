import React from 'react';
import { Link } from "react-router-dom";
import { fetchProductList } from './action/productAction';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';


const ProductList = () => {
    const dispatch = useDispatch();
    const productLists = useSelector((state) => state.productData);
    const [productList, setproductList] = useState([]);
    useEffect(() => {
        setproductList(productLists.productListRecord);
    }, [productLists])


    useEffect(() => {
        saveProductId()
    }, [])

    const saveProductId = () => {
        dispatch(fetchProductList());
    }
    return (
        <div>
            {!productList ? <h1>No CourseList Available !!!</h1> :
                <div>
                    <table className="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">ProductId </th>
                                <th scope="col">Product Title</th>
                                <th scope="col">Product Image</th>
                                <th scope="col">Description</th>
                                <th scope="col">Category</th>
                                <th scope="col">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                productList.map((myvariables, id) => (
                                    <tr key={id + 1}>
                                        <th value={id + 1} scope="row">{id + 1}</th>
                                        <td value={myvariables.title}>{myvariables.title}</td>
                                        <td value={myvariables.image} name={myvariables.id} className="productimageRow"><Link to={`/productItemDetails/${myvariables.id}`} ><img className="img-thumbnail" src={myvariables.image} alt="BigCo Inc. logo" /></Link></td>
                                        <td value={myvariables.description}>{myvariables.description}</td>
                                        <td value={myvariables.category}>{myvariables.category}</td>
                                        <td value={myvariables.price}>${myvariables.price}</td>
                                        <td value={myvariables.id} name={myvariables.id}>
                                            <Link to={`/productItemDetails/${myvariables.id}`} className="btn btn-primary">
                                                <span name={myvariables.id} >Details</span>
                                            </Link>
                                        </td>
                                    </tr>


                                ))

                            }
                        </tbody>
                    </table>

                </div>
            }
        </div>
    );
}

export default ProductList;