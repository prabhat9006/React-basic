import React from "react";
import CourseList from "./component/courseList";
import { BrowserRouter, Route,Link , Routes} from 'react-router-dom';

import Enquiry from "./component/enquiry";
import ProjectTitle from "./component/projectTitle";
import EnquiryList from "./component/enquiryList";
function App() {
  return (
    <BrowserRouter>
      <div className="container">
        <ProjectTitle />
        <Routes>
          <Route exact path="/"element={< CourseList />}></Route>
          <Route  path="enquiries"element={< Enquiry/>}></Route>
          <Route  path="enquirielist"element={< EnquiryList/>}></Route>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
