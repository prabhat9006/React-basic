import React, { Component } from 'react';
import { Link } from "react-router-dom";
import axios from 'axios';
const url = "http://localhost:3002/enquiries";

class EnquiryList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            enquiryList: []
        }
    }
    componentDidMount() {
        axios.get(url).then((response) => {
            this.setState({
                enquiryList: response.data
            })
        }).catch((err) => {
            console.log(err)
        })
    }
    render() {
        if (this.state.enquiryList.length == "0")
            return <h1>No EnquiryList Available !!!</h1>
        return (
            <div>
                {
                    <div>
                        <h3>User Enquiry List</h3>
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">FirstName</th>
                                    <th scope="col">LastName</th>
                                    <th scope="col">PhoneNumber </th>
                                    <th scope="col">CourseName </th>
                                    <th scope="col">Email</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.enquiryList.map((myvariables, id) => (
                                        <tr key={id + 1}>
                                            <th value={id + 1} scope="row">{id + 1}</th>
                                            <td value={myvariables.courseId}>{myvariables.firstName}</td>
                                            <td value={myvariables.courseId}>{myvariables.lastName}</td>
                                            <td value={myvariables.title}>{myvariables.phoneNumber}</td>
                                            <td value={myvariables.title}>{myvariables.courseName}</td>
                                            <td value={myvariables.title}>{myvariables.email}</td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>

                    </div>
                }
            </div>
        );
    }
}

export default EnquiryList;