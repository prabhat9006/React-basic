import React, { Component } from 'react';
import {Link} from "react-router-dom";
import axios from 'axios';
const url = "http://localhost:3002/courseList";

class CourseList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            courseList: []
        }
        this.updateRecord = this.updateRecord.bind(this)
    }
    componentDidMount() {
        axios.get(url).then((response) => {
            this.setState({
                courseList: response.data
            })
        }).catch((err) => {
            console.log(err)
        })
    }
    updateRecord = (event) => {
        event.preventDefault();
        const courseId = event.target.value;
        const courseItem = this.state.courseList.filter(function(item){
            return item.courseId == courseId;
        })
        console.log(courseItem);
    }

    render() {
        if (this.state.courseList.length == "0")
            return <h1>No CourseList Available !!!</h1>
        return (
            <div>
                {
                    <div>
                       
                            <table className="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">CourseId </th>
                                        <th scope="col">Course Title</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Fee</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        this.state.courseList.map((myvariables, id) => (
                                            <tr key={id + 1}>
                                                <th value = {id + 1} scope="row">{id + 1}</th>
                                                <td value={myvariables.courseId}>{myvariables.courseId}</td>
                                                <td value={myvariables.title}>{myvariables.title}</td>
                                                <td value={myvariables.description}>{myvariables.description}</td>
                                                <td value={myvariables.fee}>{myvariables.fee}</td>
                                                {/* <td value={myvariables.courseId}><button value={myvariables.courseId} onClick={this.updateRecord} className="btn btn-primary">Enquire</button></td> */}
                                                <td value={myvariables.courseId}><Link to="/enquiries" params={{ testvalue: "hello" }} value={myvariables.courseId} className="btn btn-primary">Enquire</Link></td>
                                            </tr>
                                            

                                        ))

                                    }
                                </tbody>
                            </table>
                        
                    </div>
                }
            </div>
        );
    }
}

export default CourseList;