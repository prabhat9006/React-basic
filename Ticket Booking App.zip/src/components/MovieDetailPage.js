import React from "react";
import { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { fetchSelectedMovie } from './action/movieAction';
import { useParams } from "react-router-dom";
const url = "http://localhost:3002/productList/?id=";

function MovieDetailPage() {
  const dispatch = useDispatch();
  const [selectedMovie, setSelectedMovieList] = useState([]);
  let { id } = useParams();
  if (!id) id = "1";

  
  useEffect(() => {
    getSelectedMovie(id)
  }, [])
  const getSelectedMovie = (id) => {
    dispatch(fetchSelectedMovie(id));
  }

  const movieListRecord = useSelector((state) =>  state.movieData);
 
  useEffect(() => {
    setSelectedMovieList(movieListRecord.selectedMovieRecord);
  }, [movieListRecord])

  return (
    <div className="container movie-details">
      {!selectedMovie ? <h1>No Movie Available !!!</h1> :
        selectedMovie.map((myvariables, id) => (
          <table className="table table-bordered">
            <tbody>
              <tr key={id}>
                <td>
                  <tr className="foodimage">
                    <td className="tabledata"> <img  className="foodimage" src={myvariables.image} alt="BigCo Inc. logo" /></td>
                  </tr>
                </td>
                <td>
                  <table>
                    <tbody>
                      <tr>
                        <td className="tabledata"> Title </td>
                        <td className="tabledata"> {myvariables.title} </td>
                        <td className="tabledata"> Release Date </td>
                        <td className="tabledata"> 11 March 2022 </td>
                      </tr>

                      <tr>
                        <td className="tabledata" > Durations </td>
                        <td className="tabledata" >  </td>
                        <td className="tabledata" > 2h 30m </td>
                      </tr>

                      <tr>
                        <td className="tabledata"> Rating </td>
                        <td className="tabledata">  </td>
                        <td className="tabledata"> ***** </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
              <Link to={`/moviebookingdetail/${myvariables.id}`}> <td><button type="button" className="btn btn-primary book-now--btn"> Book Now </button></td>
                <td></td>
              </Link>
              </tr>
            </tbody>
          </table>

        )
        )
      }

    </div>
  );
}

export default MovieDetailPage;



