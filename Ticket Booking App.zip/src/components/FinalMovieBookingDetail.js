import React from "react";
import { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { fetchSelectedMovie } from './action/movieAction';
import { useParams } from "react-router-dom";
import Select from 'react-select';
const url = "http://localhost:3002/productList/?id=";
const barocde = "https://barcode.tec-it.com/barcode.ashx?data=he6fe54u4s56o71d36z51no&code=Code128&multiplebarcodes=true&translate-esc=true";


function FinalMovieBookingDetail() {
  // const dispatch = useDispatch();
  const [selectedMovie, setSelectedMovieList] = useState([]);

  const movieListRecord = useSelector((state) =>  state.movieData);
 
  useEffect(() => {
    setSelectedMovieList(movieListRecord.boockedMovieRecord);
  }, [movieListRecord])

const getDate = ()=>{
  let date = new Date(selectedMovie.movieDate);
  const fulldate  = date.getDate() + "/" + date.getMonth()+"/"+ date.getFullYear();
  return fulldate;
}
const getTime = ()=>{
  let date = new Date(selectedMovie.movieDate);
  const Time  = date.getHours() + ":" + date.getMinutes();
  return Time;
}
if(selectedMovie && selectedMovie.length == "0"){
return (<h1>No Movie Available !!!</h1>); 
}
  return (
    <div className="container movie-details">
      {
      (selectedMovie && selectedMovie.length == "0") ? <h1>No Movie Available !!!</h1> :
       
          <table className="table table-bordered">
            <tbody>
              <tr key="1">
              <td>
                  <tr className="foodimage">
                    <td className="tabledata"> <img  className="movieimage" src={barocde} alt="BigCo Inc. logo" /></td>
                  </tr>
                </td>
                <td>
                  <table>
                    <tbody>
                      <tr>
                        <td className="tabledata"> Number of Seats:</td>
                        <td className="tabledata"> </td>
                        <td className="tabledata">{selectedMovie.NumberOfSeat.label} </td>
                      </tr>
                      <tr>
                        <td className="tabledata"> Date </td>
                        <td className="tabledata">{getDate()} </td>
                      </tr>
                      <tr>
                        <td className="tabledata"> Time </td>
                        <td className="tabledata"> {getTime()}  </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              
            </tbody>
          </table>
      
      }

    </div>
  );
}

export default FinalMovieBookingDetail;



