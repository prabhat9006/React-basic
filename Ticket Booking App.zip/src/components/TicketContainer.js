// @flow
import * as React from 'react';
import TabList from './TabList';
import MovieList from './MovieList';
export function TicketContainer() {
  return (
    <div>
      <TabList/>
    </div>
  );
};