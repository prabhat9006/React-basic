import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';


import pic1 from "../Image/movie-image-5.jpg";
import pic2 from "../Image/movie-image-6.jpeg";
import pic3 from "../Image/movie-image-7.jpg";
import { Carousel } from 'react-bootstrap';

export default function MovieSlider() {
return (
	<div className="slider-cls">
	<Carousel>
		<Carousel.Item interval={2000}>
		<img
			className="d-block w-100 slider-cls-image"
             src={pic1}
			alt="Image One"
		/>
		<Carousel.Caption>
			
		</Carousel.Caption>
		</Carousel.Item>
		<Carousel.Item interval={2000}>
		<img
			className="d-block w-100 slider-cls-image"
			src={pic2}
			alt="Image Two"
		/>
		<Carousel.Caption>
			
		</Carousel.Caption>
		</Carousel.Item>
        <Carousel.Item interval={2000}>
		<img
			className="d-block w-100 slider-cls-image"
			src={pic3}
			alt="Image Two"
		/>
		<Carousel.Caption>
			
		</Carousel.Caption>
		</Carousel.Item>
	</Carousel>
	</div>
);
}
