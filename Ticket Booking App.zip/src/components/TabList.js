import React from "react";
import Paper from "@material-ui/core/Paper";
import Tab from "@material-ui/core/Tab";
import Tabs from "@material-ui/core/Tabs";
import MovieList from "./MovieList";
import LatestMovieList from "./LatestMovieList";
import UpcomingMovieList from "./UpcomingMovieList";
import NearByEvent from "./ NearByEvent";
import { Link } from "react-router-dom";
import MovieSlider from "./MovieSlider";
import Recomadation from "./Recomadation";

const TabList = () => {
    const [value, setValue] = React.useState(0);
    const [tabName, setTabName] = React.useState("latestmovielist");

    const changeTab = (event, newValue) => {
        setValue(newValue);
        setTabName(event.currentTarget.name);
    }
    return (
        <div className="container tab-cls">

            <Paper square>
                <Tabs
                    value={value}
                    textColor="primary"
                    indicatorColor="primary"
                    className="tab-list"
                    onChange={changeTab}
                >
                    {/* <Link to='/latestmovielist'><Tab label="Latest Movie" name="latestmovielist"  className="tab-list-item"/></Link>
                    <Link to='/upcomingmovielist'><Tab label="Upcoming Movie" name="upcomingmovielist"  className="tab-list-item" /></Link>
                    <Link to='/nearbyevent'><Tab label="Nearby Events" name="nearbyevent"  className="tab-list-item" /></Link> */}
                   
                    <Tab label="Latest Movie" className="tab-list-item" name="latestmovielist" />
                    <Tab label="Upcoming Movie" className="tab-list-item" name="upcomingmovielist" />
                    <Tab label="Nearby Events" className="tab-list-item" name="nearbyevent" />

                </Tabs>
               <MovieSlider/>
               {/* <Recomadation/> */}
                {tabName == "latestmovielist" ?
                    <LatestMovieList />
                    :
                    tabName && tabName == "upcomingmovielist" ?
                        <UpcomingMovieList />
                        :
                        <NearByEvent />
                }
            </Paper>
        </div>
    );
};

export default TabList;
