import movieData from "./movieData";

import {combineReducers} from "redux";


const rootReducer = combineReducers({
   movieData
})
export default rootReducer;