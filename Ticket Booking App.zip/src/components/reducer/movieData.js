
const movieData = (state = {}, action) => {

    switch (action.type) {
        case 'DISPLAY_MOVIE_RECORDS':
            return { ...state, movieListRecord: action.payload }
         case 'DISPLAY_EVENT_RECORDS':
            return { ...state, displayEvent: action.payload }
        case 'DISPLAY_SELECTED_MOVIE_RECORD':
            return { ...state, selectedMovieRecord: action.payload} 
        case 'SAVE_SELECTED_MOVIE_RECORD':
            return { ...state, boockedMovieRecord: action.payload}
        default:
            return state;

    }
}
export default movieData;