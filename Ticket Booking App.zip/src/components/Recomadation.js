import React from 'react';
import { Link } from "react-router-dom";
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchMovieList } from './action/movieAction';

const Recomadation = () => {
  const dispatch = useDispatch();
  const movieListRecord = useSelector((state) => state.movieData);
  const [movies, setMovieList] = useState([]);
  useEffect(() => {
    setMovieList(movieListRecord.movieListRecord);
  }, [movieListRecord])


  useEffect(() => {
    saveMovieList()
  }, [])

  const saveMovieList = () => {
    dispatch(fetchMovieList());
  }
  return (
    <div>
      {!movies ? <h1>No Recomadation Movie List Available !!!</h1> :
        <div className="ui grid container">
          {
            movies.map((myvariables, id) => (
              <div className="four wide column" key={id}>
                <Link to={`/moviedetailpage/${myvariables.id}`}>
                  <div className="ui link cards">
                    <div className="card">
                      <div className="image">
                        <img src={myvariables.image} alt="BigCo Inc. logo" />
                      </div>
                      <div className="content">
                        <div className="header">{myvariables.title}</div>
                        <div className="meta">{myvariables.genre}</div>
                        <div className="meta">{myvariables.stars}</div>
                        <div className="meta">{myvariables.director}</div>
                        <div className="meta"><button type="button" className="btn btn-primary book-btn">BOOK</button></div>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))

          }
        </div>
      }
    </div>
  );
}

export default Recomadation;