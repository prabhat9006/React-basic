import axios from "axios";
const url2 = "http://localhost:3002/movies";
const event = "http://localhost:3002/event";
const url = "http://localhost:3002/movies/?id=";


export const fetchMovieList = () => {
  return dispatch => {
      axios.get(url2).then(response => {
      dispatch({
          type: "DISPLAY_MOVIE_RECORDS",
          payload: response.data
      });
    });
  };
};

export const fetchEventList = () => {
  return dispatch => {
      axios.get(event).then(response => {
      dispatch({
          type: "DISPLAY_EVENT_RECORDS",
          payload: response.data
      });
    });
  };
};

export const fetchSelectedMovie = (id) => {
  return dispatch => {
      axios.get(url+`${id}`).then(response => {
      dispatch({
          type: "DISPLAY_SELECTED_MOVIE_RECORD",
          payload: response.data
      });
    });
  };
};

export const saveSelectedMovie = (payload) => {
  return {
    type: "SAVE_SELECTED_MOVIE_RECORD",
    payload: payload
  }
};
