// @flow
import * as React from 'react';

export class ProjectTitle extends React.Component {
  render() {
    return (
      <div className="container">
        <h5>Build an Online Movie Ticket Booking Web-Application using React and
          Redux</h5>

        <p>E-Cube is a web application, which allows user to book online tickets for latest movies, concerts
          and other LIVE events happening in the city. With the increase in web traffic, E-Cube’s website
          load time increases significantly which in turn reduces the speed and performance of the
          website. It was earlier designed using traditional web development methodologies. Also, on
          adding or updating any feature, maintaining the website was difficult for the development team
          due to tight coupling of UI components. Hence, all these challenges led to unsatisfied user
          experience. Now they want to focus on maximizing the usability and enhancing the user experience, so the
          company decided to upgrade their website using React library.</p>

      </div>
    )
  };
};