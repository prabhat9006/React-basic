import React from "react";
import { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { fetchSelectedMovie , saveSelectedMovie } from './action/movieAction';
import { useParams } from "react-router-dom";
import Select from 'react-select';
const url = "http://localhost:3002/productList/?id=";

function MovieBookingDetail() {
  const dispatch = useDispatch();
  const [selectedMovie, setSelectedMovieList] = useState([]);
  const [selectedOption, saveSelectedSeat] = useState(1);
  const [movieDate, saveSelectedDate] = useState("");
  let { id } = useParams();
  if (!id) id = "1";

  
  useEffect(() => {
    getSelectedMovie(id)
  }, [])
  const getSelectedMovie = (id) => {
    dispatch(fetchSelectedMovie(id));
  }

  const movieListRecord = useSelector((state) =>  state.movieData);
 
  useEffect(() => {
    setSelectedMovieList(movieListRecord.selectedMovieRecord);
  }, [movieListRecord])
 const  handleChange = (selectedOption) => {
  saveSelectedSeat(selectedOption);
  };

  const  handleChangeDate = (item) => {
    console.log(item);
    saveSelectedDate(item.currentTarget.value);
  };
  const  
  
    saveSelectedDateAndTime = () => {
      const payload = {
        "NumberOfSeat": selectedOption,
        "movieDate": movieDate
      }
      dispatch(saveSelectedMovie(payload));
    }

  const options = [
    { value: '1', label: '1' },
    { value: '2', label: '2' },
    { value: '3', label: '3' },
  ];

  return (
    <div className="container movie-details">
      {!selectedMovie ? <h1>No Movie Available !!!</h1> :
        selectedMovie.map((myvariables, id) => (
          <table className="table table-bordered">
            <tbody>
              <tr key={id}>
                <td>
                  <table>
                    <tbody>
                      <tr>
                        <td className="tabledata"> Date </td>
                        <td className="tabledata"> <input onChange={handleChangeDate}  type="datetime-local"></input> </td>
                      </tr>
                      <tr>
                        <td className="tabledata-select"> Choose number of seats </td>
                      
                        <td className="tabledata-select">  
                        <Select
                          value={selectedOption}
                          onChange={handleChange}
                          options={options}
                        />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
              <Link to="/finalmoviebookingdetail"> <td><button type="button" onClick={saveSelectedDateAndTime} className="btn btn-primary book-now--btn"> Book </button></td>
                <td></td>
              </Link>
              </tr>
            </tbody>
          </table>

        )
        )
      }

    </div>
  );
}

export default MovieBookingDetail;



