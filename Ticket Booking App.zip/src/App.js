import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import MovieList from "./components/MovieList";
import Recomadation from "./components/Recomadation";
import LatestMovieList from "./components/LatestMovieList";
import UpcomingMovieList from "./components/UpcomingMovieList";
import NearByEvent from "./components/ NearByEvent";
import Header from "./components/Header";
import TabList from "./components/TabList";
import MovieDetailPage from "./components/MovieDetailPage";
import { TicketContainer } from "./components/TicketContainer";
import MovieSlider from "./components/MovieSlider";
import MovieBookingDetail from "./components/MovieBookingDetail";
import FinalMovieBookingDetail from "./components/FinalMovieBookingDetail";
function App() {
  return (
    <div className="container">
      <BrowserRouter>
        <Header />
        {/* <MovieSlider/> */}
        {/* <TicketContainer/> */}
        <Routes>
          <Route path="/" element={<TicketContainer/>}></Route>
          <Route path="/movieList" element={<MovieList />}></Route>
          <Route path="/latestmovielist" element={<LatestMovieList />}></Route>
          <Route path="/upcomingmovielist" element={<UpcomingMovieList />}></Route>
          <Route path="/nearbyevent" element={<NearByEvent />}></Route>
          <Route path="/recomadation" element={<Recomadation />}></Route>
          <Route path="/moviedetailpage" element={<MovieDetailPage/>}></Route>
          <Route path="/moviedetailpage/:id" element={<MovieDetailPage/>}></Route>
          <Route path="/moviebookingdetail/:id" element={<MovieBookingDetail/>}></Route>
          <Route path="finalmoviebookingdetail" element={<FinalMovieBookingDetail/>}></Route>
          <Route>404 Not Found!</Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;