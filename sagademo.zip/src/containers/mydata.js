import React from 'react'
import { connect } from 'react-redux'

let Mydata = ({ mydata }) => (
    mydata ? (
        <div className="container">
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Country Code </th>
                        <th scope="col">Name of University</th>
                        <th scope="col">Domains</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        mydata.map((myvariables, id) => (
                            <tr key={id + 1}>
                                <th scope="row">{id + 1}</th>
                                <td>{myvariables.alpha_two_code}</td>
                                <td>{myvariables.name}</td>
                                <td>{myvariables.domains[0]}</td>
                            </tr>

                        ))
                    }
                </tbody>
            </table>
        </div>)
        :
        null
)

const mapStateToProps = (state) => (
    {
        mydata: state.mydatas
    }
)
//mapDispatchToProps is absent, In connect it will occupy
//the 2nd parameter. Hence we need to pass null
Mydata = connect(mapStateToProps, null)(Mydata)
export default Mydata