import React from 'react'
import { connect } from 'react-redux'
import image from './loadingimage.gif'

let Loading = ({ loading }) => (
    loading ?
        <div>
            <img src={image} alt="Loading" />
        </div>
        :
        null
)

const mapStateToProps = (state) => (
    {
        loading: state.loading
    }
)
//mapDispatchToProps is absent, In connect it will occupy
//the 2nd parameter. Hence we need to pass null
Loading = connect(mapStateToProps, null)(Loading)
export default Loading
