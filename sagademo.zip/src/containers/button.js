import React from 'react'
import { connect } from 'react-redux'
import { getSomedata } from '../actions'

let Button = ({ getdata }) => (
    <div className="container">
        <button className="btn btn-primary" onClick={getdata}>
            Click Here For Getting The Data
        </button>
    </div>
)

const mapDispatchToProps = {
    getdata: getSomedata
}
//mapSTatetoProps is absent, In connect it will occupy
//the 1st parameter. Hence we need to pass null
Button = connect(null, mapDispatchToProps)(Button)
export default Button