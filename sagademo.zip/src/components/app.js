import React from 'react'
import Button from '../containers/button'
import Loading from '../containers/loadingimage.js'
import Mydata from '../containers/mydata'

let App = () => (
    <div>
        <Button />
        <Loading />
        <Mydata />
    </div>
)

export default App

//When we execute our project - Display a button
//When the button is clicked, we make a call to an api - These api will
//provide us with some response data
//After the click of the button, we async trigger a loading icon and this
//icon will be displayed until the data is received.
//Once the data is received we will display the data