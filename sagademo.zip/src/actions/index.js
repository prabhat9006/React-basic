export const getSomedata = () => (
    {
        type: 'GET_DATA'
    }
)
//getSomeData = help us in creation of the action
//type = invoke the action - action type