const reducer = (state = {}, action) => {
    switch (action.type) {
        case 'GET_DATA':
            return { ...state, loading: true }    //loading button
        case 'GOT_DATA':
            return { ...state, loading: false, mydatas: action.passdata }    //remove load button & load the data
        default:
            return state
    }

}
export default reducer