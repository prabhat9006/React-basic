import { all, takeLatest, put } from "@redux-saga/core/effects"

function* getTheData() {
    const datareceived = yield fetch('http://universities.hipolabs.com/search?country=United+States')
        .then(response => response.json())
    //datareceived - array of data with 100 records from json placeholder web
    yield put({ type: 'GOT_DATA', passdata: datareceived, })
}

function* myWatcher() {
    yield takeLatest('GET_DATA', getTheData)
}

export default function* rootSaga() {
    yield all([myWatcher(),])
}