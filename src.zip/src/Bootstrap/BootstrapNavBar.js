

import { Link, NavLink } from 'react-router-dom'
import React from 'react';
import { Navbar, Container, Nav  } from 'react-bootstrap';

class BootstrapNavBar extends React.Component {
    render() {
        return (
            <>
                <Navbar bg="primary" variant="dark">
                    <Container>
                        <Navbar.Brand as={Link} to="/">Navbar</Navbar.Brand>
                        <Nav className="me-auto">
                            <Nav.Link as={NavLink} to="/">Home</Nav.Link>
                            <Nav.Link as={NavLink} to="/about">About</Nav.Link>
                            <Nav.Link as={NavLink} to="/contact">Contact</Nav.Link>
                        </Nav>
                    </Container>
                </Navbar>
            </>

        )
    }
}
export default BootstrapNavBar;