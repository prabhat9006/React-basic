import React from 'react';
import { Route, BrowserRouter, Routes } from 'react-router-dom';
import BootstrapNavBar from './BootstrapNavBar';
import BootstrapClass from './BootstrapClass';
import Home from '../Router/Home';
import About from '../Router/About';
import Contact from '../Router/Contact';

class ParentBootstrap extends React.Component {
  render() {
    return (
      <div>
        <BrowserRouter>
          <BootstrapNavBar />
          
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
          <BootstrapClass />
        </BrowserRouter>
      </div>
    )
  }
}
export default ParentBootstrap;