import { useState, useContext, createContext, React } from "react";
// import ChildUseContextExample from "./ChildUseContextExample.js";

// const UserContext = createContext();

// function UseContextExample() {
//     const [user, setUser] = useState("Prabhat");

//     return (
//         <UserContext.Provider value={user}>
//             <h1>UseContextExample</h1>
//             <h2>{`Hello ${user} !`}</h2>
//             <ChildUseContextExample />
//         </UserContext.Provider>
//     );
// }
// export default UseContextExample;



const themes = {
    light: {
      foreground: "#000000",
      background: "#eeeeee"
    },
    dark: {
      foreground: "#ffffff",
      background: "#222222"
    }
  };
  
  const ThemeContext = createContext();

  
  function UseContextExample() {

    return (
      <ThemeContext.Provider value={themes.light}>
        <Toolbar />
      </ThemeContext.Provider>
    );
  }
  
  function Toolbar(props) {
    return (
      <div>
        <ThemedButton />
      </div>
    );
  }
  
  function ThemedButton() {
    const theme = useContext(ThemeContext);
    return (
      <button style={{ background: theme.background, color: theme.foreground }}>
        I am styled by theme context!
      </button>
    );
  }

  export default UseContextExample;