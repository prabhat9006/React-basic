// import { useState, useContext , React } from "react";
// import UserContext from "./UseContextExample.js"

// function ChildUseContextExample() {

//     const user = useContext(UserContext);
//   console.log(user);
//     return (
//       <>
//         <h1> ChildUseContextExample </h1>
//         <h2>{`Hello ${user} again!`}</h2>
//       </>
//     );
//   }

//   export default ChildUseContextExample;