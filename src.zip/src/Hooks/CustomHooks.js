
import useFetch from "./useFetch";

const CustomHooks = () => {
    const [data] = useFetch("https://jsonplaceholder.typicode.com/todos");

    function isEmptyObject(value) {
        if (value)
            return (Object.keys(value).length === 0 && value.constructor === Object)
        else {
            return true
        }

    }

    if (isEmptyObject(data)) {
        return <div>Data Not Available.</div>
    }
    console.log(isEmptyObject(data))

    return (
        <>
            {data &&
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">SL#</th>
                            <th scope="col">Title</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map((myvariables, id) => (
                                <tr key={myvariables.id + 1}>
                                    <th scope="row">{id + 1}</th>
                                    <td>{myvariables.title}</td>
                                </tr>

                            ))
                        }
                    </tbody>
                </table>
            }
        </>

    );
};

export default CustomHooks;


