import React, { Component } from 'react';

class ErrorBoundary extends React.Component {  
    constructor(props) {  
      super(props);  
      this.state = { 
        hasError: false,
        error: "",
        errorInfo: "",
      
      };  
    }  
    static getDerivedStateFromError(error) {  
      // It will update the state so the next render shows the fallback UI.  
      return { hasError: true };  
    }  
    componentDidCatch(error, info) {
      this.setState({ 
        hasError: true,
        error: error,
        errorInfo: info
      
      });
    } 
    render() {  
      if (this.state.hasError) {  
          return (  
          <div style={{color:"red"}}>
            <h5 >Error:</h5> {this.state.error.toString()}
            <h5 >ErrorInfo:</h5> {this.state.errorInfo.componentStack}
          </div>
      );  
      }  
      return this.props.children;   
    }  
  }  

  export default ErrorBoundary;