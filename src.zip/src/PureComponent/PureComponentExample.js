import React, { Component, PureComponent } from 'react';

// class PureComponentExample extends Component {
class PureComponentExample extends PureComponent {
    constructor(){
        super();
        this.state = {
            counter: 10
        }
    }
    shouldComponentUpdate(nextProps, nextState){
        debugger
        if(nextState.counter == "20"){
            return true
        }
    }
    render() {
        console.log(this.state.counter);
        return (
            <div>
                value is : {this.state.counter}
                <button onClick={()=>{this.setState({"counter": 20})}}>Click me </button>
            </div>
        );
    }
}

export default PureComponentExample;