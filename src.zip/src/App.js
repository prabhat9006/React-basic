import LifecycleUnMount from "./LifeCycle/LifecycleUnMount";
import ControlledComponent from "./Forms/ControlledComponent";
import FlavorForm from "./Forms/FlavorForm";
import UnControlledComponent from "./Forms/UnControlledComponent";
import RenderRouter from "./Router/RenderRouter";
import LinkRenderRouter from "./Router/LinkRenderRouter";
// import ParentBootstrap from "./Bootstrap/ParentBootstrap";
import ErrorBoundary from "./ErrorBoundry/ErrorBoundary";
import BuggyCounter from "./ErrorBoundry/BuggyCounter";
import PureComponentExample from "./PureComponent/PureComponentExample";
// import LazyLoad from "./LazyLoad/LazyLoad";
import React, { lazy, Suspense } from "react";
// const LazyLoad = lazy(() => import("./LazyLoad/LazyLoad"))
import ParentForwardRef from "./ForwardRefExample/ParentForwardRef";
import CountAppUseState from "./Hooks/CountAppUseState";
import CounterAppUseEffect from "./Hooks/CounterAppUseEffect";
import UseContextExample from "./Hooks/UseContextExample";
import UseRefExpmale from "./Ref/UseRefExpmale.js";
import CreateRefExample from "./Ref/CreateRefExample.js";
import WithOutuseMemoExample from "./Hooks/WithOutuseMemoExample";
import UseMemoExample from "./Hooks/UseMemoExample";
import CustomHooks from "./Hooks/CustomHooks";
import UseCallBackExample from "./Hooks/UseCallBackExample";

function App() {
  return (
    <div className="App">
      {/* <LifecycleUnMount /> */}
      {/* <ControlledComponent /> */}
      {/* <FlavorForm/> */}
      {/* <UnControlledComponent /> */}
      {/* <RenderRouter/> */}
      {/* <LinkRenderRouter/> */}
      {/* <BootstrapClass /> */}
      {/* <ParentBootstrap/> */}
      {/* <ErrorBoundary>
        <BuggyCounter />
      </ErrorBoundary>

      <BuggyCounter /> */}
      {/* <PureComponentExample/> */}
      {/* <Suspense fallback={<div>Please wait...</div>}>
        <LazyLoad />
      </Suspense> */}
      {/* <ParentForwardRef /> */}
      {/* <CountAppUseState /> */}
      {/* <CounterAppUseEffect /> */}
      {/* <UseContextExample /> */}

      {/* <UseRefExpmale /> */}
      {/* <CreateRefExample /> */}
      {/* <WithOutuseMemoExample /> */}
      {/* <UseMemoExample /> */}
      {/* <CustomHooks /> */}
      <UseCallBackExample />

    </div>
  );
}

export default App;
