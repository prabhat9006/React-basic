import React from 'react';
// import Home from './Home';
// import About from './About';
// import Contact from './Contact';
import { Route, BrowserRouter, Routes, Link } from 'react-router-dom';
class Header extends React.Component {
    render() {
        return (
            <div>
                <h1>React Router Link Example</h1>
                <ul className="App-header">
                    <li>
                        <Link to="/">Home</Link>

                    </li>
                    <li>
                        <Link to="/about">About Us</Link>
                    </li>
                    <li>
                        <Link to="/contact">Contact Us</Link>
                    </li>
                </ul>
            </div>
        )
    }
}
export default Header;

