import React, { Component } from 'react';
import { Route, BrowserRouter, Routes } from 'react-router-dom';
import Home from './Home';
import About from './About';
import Contact from './Contact';
class RenderRouter extends React.Component {
    render() {
        return (
            <div>
                <h1>React Router Example</h1>
                <div>
                    <BrowserRouter>
                        <Routes>
                            <Route exact path="/" element={<Home/>} />
                            <Route path="/about" element={<About/>} />
                            <Route path="/contact" element={<Contact/>} />
                        </Routes>
                    </BrowserRouter>
                </div>
            </div>
        )
    }
}
export default RenderRouter;