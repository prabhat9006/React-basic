import React, { useRef } from "react";
import ChildForwardRef from "./ChildForwardRef";


function ParentForwardRef() {

    const inputValue = useRef("Prabhat");

    const onclickHandler = (evnt) => {
        evnt.preventDefault();
        console.log(inputValue.current.value);
    }

    return (
        <div>
            <ChildForwardRef ref={inputValue} placeholder = {"Please Enter Your Name"}/>
            <button onClick={onclickHandler}>Ckick Me</button>
        </div>
    )
}
export default ParentForwardRef;