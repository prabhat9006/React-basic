import React from "react";

const childForwardRef = React.forwardRef((props, ref) => {
    console.log(ref)
    return (
    <div>
        <input type="text" ref={ref} defaultValue = {ref.current} placeholder = {props.placeholder}/>
    </div>
    )
})
export default childForwardRef;