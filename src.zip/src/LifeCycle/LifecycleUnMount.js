import React, { Component } from 'react';
import Lifecycle from './Lifecycle';

class LifecycleUnMount extends React.Component {
  constructor(){
    super()
    this.state={
      toggle : true
    }
  }
  render() {
    return (
      <div className="App">
        <h1>Prabhat</h1>
        {
          this.state.toggle ? <Lifecycle /> : "No Lifecycle Class"
        }
        
        <button onClick={() => { this.setState({ toggle: !this.state.toggle }) }}>Remove Lifecycle Event Component</button>
      </div>
    );
  }

}
export default LifecycleUnMount;
