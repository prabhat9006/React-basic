import React, { Component, Suspense, lazy } from 'react';

const Home = lazy(() => import("../Router/Home"))
class LazyLoad extends Component {
    render() {
        return (
            <div>
                <h1>Lazy Loading</h1>
                <Suspense fallback={<div>Please wait...Home</div>}>
                    <h1><Home /></h1>
                </Suspense>
            </div>
        );
    }
}

export default LazyLoad;