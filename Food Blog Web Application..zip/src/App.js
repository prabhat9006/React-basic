import { BrowserRouter, Routes, Route } from "react-router-dom";

import ProjectTitle from "./component/projectTitle";
import FoodItemDetails from "./component/foodItemDetails";
import FoodList from "./component/foodList";
import { Home } from "./component/Home";
import "../src/CSS_Files/style.css"
function App() {
  return (
    <div className="container">
      <BrowserRouter>
        <ProjectTitle />
        <Routes>
          <Route path="/" element={<Home/>}></Route>
          <Route path="/foodlist" element={<FoodList/>}></Route>
          <Route path="/fooditemdetails" element={<FoodItemDetails/>}></Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
