import React, { Component } from 'react';
import { getSelectedFoodRecords } from './action/foodActions';

import { connect } from 'react-redux';


const mapDispatchToProps = (dispatch) => {
    return {
        getSelectedFoodRecords: (id) => dispatch(getSelectedFoodRecords(id))
    }

}

const mapStateToProps = (props) => {
    return {
        displaySelectedFoodRecords: props.foodData.displaySelectedFoodRecords ? props.foodData.displaySelectedFoodRecords : [],
        showEnquiryListRecord: props.foodData.showEnquiryListRecord ? props.foodData.showEnquiryListRecord : true,
        foodId: props.foodData.foodId ? props.foodData.foodId : "1",
    }

}
class FoodItemDetails extends Component {
  componentDidMount() {
        this.props.getSelectedFoodRecords(this.props.foodId);
    }
    render() {
        if (this.props.showEnquiryListRecord && this.props.displaySelectedFoodRecords.length == 0)
            return <h1>No Food Item Details !!!</h1>
        return (
            <div className="container">
                {
                    <div>
                        <h3>Food Item Details</h3>
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Food Title</th>
                                    <th scope="col" className="fooditemImage" >Food Image </th>
                                    <th scope="col">Food Description</th>
                                    <th scope="col">Food Area</th>
                                    <th scope="col">Food Tag</th>
                                    <th scope="col">Food Ingredients</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.props.displaySelectedFoodRecords.map((myvariables, id) => (
                                        <tr key={id + 1}>
                                            <th value={id + 1} scope="row">{id + 1}</th>
                                            <td value={myvariables.strMeal}>{myvariables.strMeal}</td>
                                            <td value={myvariables.strMealThumb} className="fooditemImage"><img className="img-thumbnail fooditemImage" src={myvariables.strMealThumb} alt="BigCo Inc. logo" /></td>
                                            <td value={myvariables.strInstructions}>{myvariables.strInstructions}</td>
                                            <td value={myvariables.strArea}>{myvariables.strArea}</td>
                                            <td value={myvariables.strTags}>{myvariables.strTags}</td>
                                            <td>
                                                <table className="table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th scope="col">#</th>
                                                            <th scope="col">Food Ingredients</th>
                                                        </tr>
                                                    </thead>
                                                    {
                                                        myvariables.ingredients.map((item, id) => (
                                                            <tr value={id + 1}>
                                                                <th value={id + 1} scope="row">{id + 1}</th>
                                                                <td value={item.strIngredient}>{item.strIngredient}</td>
                                                                <td value={item.strMeasure}>{item.strMeasure}</td>
                                                            </tr>

                                                        ))
                                                    }
                                                </table>
                                            </td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>

                    </div>
                }
            </div>
        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(FoodItemDetails);