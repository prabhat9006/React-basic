import {all, takeLatest, takeEvery , put} from "@redux-saga/core/effects"

import axios from "axios";
const url2 = "http://localhost:3002/foodlist";
const url = "http://localhost:3002/foodItemDetails?id=";


function* fetchSelectedFoodList(param) {
   const id = param.value;
    const datareceived = yield fetch(`${url}${id}`)
        .then(response => response.json())
    //datareceived - array of data with 100 records from json placeholder web
    yield put({ type: 'DISPLAY_SELECTED_FOOD_RECORDS', passdata: datareceived, })
}

export default function* getDataSelected() {
    yield takeLatest('GET_SELECTED_FOOD_RECORD', fetchSelectedFoodList)
}
