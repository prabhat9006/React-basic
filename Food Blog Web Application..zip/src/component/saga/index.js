import {all,fork} from "@redux-saga/core/effects";
import getData from "./getData";
import getDataSelected from "./getDataSelected";
import setFoodId from "./setFoodId";


const appSaga = [fork(getData), fork(getDataSelected), fork(setFoodId)]
export default function* rootSaga() {
    yield all([...appSaga]);
}
