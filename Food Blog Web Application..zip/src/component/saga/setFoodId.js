import {all, takeLatest, takeEvery , put} from "@redux-saga/core/effects";

function* setFoodItemId(param) {
   const id = param.value;
    yield put({ type: 'GET_SELECTED_FOOD_ITEM', foodId: id, })
}

export default function* setFoodId() {
    yield takeLatest('POST_SELECTED_FOOD_ITEM', setFoodItemId)
}
