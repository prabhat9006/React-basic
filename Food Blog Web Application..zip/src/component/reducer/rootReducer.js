import foodData from "./foodData";

import {combineReducers} from "redux";


const rootReducer = combineReducers({
   foodData
})
export default rootReducer;