
const courseData = (state = {}, action) => {

    switch (action.type) {
        case 'DISPLAY_FOOD_RECORDS':
            return { ...state, foodDataRecord: action.passdata }        
        case 'GET_FOOD_RECORDS':
            return { ...state, loading: true }
        case 'GET_SELECTED_FOOD_RECORD':
                return { ...state, loading: false , foodId: action.value} 
        case 'POST_SELECTED_FOOD_ITEM':
                return { ...state, foodId: action.value} 
        case 'GET_SELECTED_FOOD_ITEM':
                return { ...state , foodId: action.foodId}
        case 'DISPLAY_SELECTED_FOOD_RECORDS':
            return { ...state, displaySelectedFoodRecords: action.passdata , showEnquiryListRecord: false}
        default:
            return state;

    }
}
export default courseData;