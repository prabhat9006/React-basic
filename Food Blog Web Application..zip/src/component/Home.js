// @flow
import * as React from 'react';

export class Home extends React.Component{
  render() {
    return (
      <div className="container">
         <h5>Food Blog Web Application.</h5>
                <p>Create a Food Blog application using React, Redux and Saga Middleware. Follow the below steps to build the application.</p>

                <h5>1.Make use of JSON server to build APIs and consume the APIs using Saga.</h5>
                <h5>2.First page of application should display fooditems.</h5>
                <h5>3.On clicking any food item, user should be navigated to respective food item’s details page.</h5>
                <h5>4.Below every food item the application should have a details button,which (on clicking) should route user to respective food recipe.</h5>
                <h5>5.Make use of Bootstrap to design the application.</h5>
                <h5>6.Make use of Axios with saga to make an API call.</h5>
      </div>
    );
  };
};