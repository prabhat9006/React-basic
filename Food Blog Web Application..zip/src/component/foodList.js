import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { fetchFoodList , postFoodid} from './action/foodActions';
import { connect } from 'react-redux';
// https://github.com/justmatt18/food-recipe/blob/main/src/api/index.js
// https://www.youtube.com/watch?v=hXpYQqykORU
const mapDispatchToProps = (dispatch) => {
    return {
        fetchFoodList: () => dispatch(fetchFoodList()),
        saveFoodItemId: (foodId) => dispatch(postFoodid(foodId))
    }
}
const mapStateToProps = (state) => {
    return {
        foodList: state.foodData.foodDataRecord
    }
}

class FoodList extends Component {

    componentDidMount() {
        this.props.fetchFoodList();
    }
    saveFoodId = (e) => {
        e.preventDefault();
        console.log(e)
        const foodId = e.currentTarget.getAttribute("name");
        this.props.saveFoodItemId(foodId);
    }
    render() { 
        
        return (
            <div className="container">
                {!this.props.foodList ?<h1>No FoodList Available !!!</h1> :
                    <div>
                        <h3> Food List </h3>
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Food Title</th>
                                    <th scope="col" className="foodimageRow" >Food Image </th>
                                    <th scope="col">Food Area</th>
                                    <th scope="col">Food Tag</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                   this.props.foodList.map((myvariables, id) => (
                                        <tr key={id + 1}>
                                            <th value={id + 1} scope="row">{id + 1}</th>
                                            <td value={myvariables.name}>{myvariables.name}</td>
                                            <td value={myvariables.photo_url}  name={myvariables.id} onClick={this.saveFoodId} className="foodimageRow"><Link to="/fooditemdetails" ><img className="img-thumbnail foodimage" src={myvariables.photo_url} alt="BigCo Inc. logo"/></Link></td>
                                            <td value={myvariables.strArea}>{myvariables.strArea}</td>
                                            <td value={myvariables.strTags}>{myvariables.strTags}</td>
                                           <td value={myvariables.id} name={myvariables.id} onClick={this.saveFoodId}>
                                               <Link to="/fooditemdetails" className="btn btn-primary"> 
                                               <span name={myvariables.id} >Details</span>
                                               </Link>
                                           </td>
                                        </tr>


                                    ))

                                }
                            </tbody>
                        </table>

                    </div>
                }
            </div>
        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(FoodList);