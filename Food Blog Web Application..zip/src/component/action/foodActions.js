export const fetchFoodList = () => {
  return {
    type: "GET_FOOD_RECORDS"
  }
};

export const getSelectedFoodRecords = (props) => {
  return {
    type: "GET_SELECTED_FOOD_RECORD",
    value: props
  }
};


export const postFoodid = (payload) => {
 // const foodId = payload.currentTarget.getAttribute("name");
  return {
    type: "POST_SELECTED_FOOD_ITEM",
    value: payload
  }
};