import React, { Component } from 'react';
import Label from "../components/Label";
import { increment, decrement ,resetCounter } from "../redux/actions/counterAction.js";
import {connect} from "react-redux";

const mapDispatchToProps = (dispatch) =>{
    return {
        increment: ()=> dispatch(increment()),
        decrement : ()=> dispatch(decrement()),
        resetCounter : ()=> dispatch(resetCounter()),
    }
}
const mapStateToProps = (props)=>{
    return{
        counterValue: props.counterReducer
    }
   
}

class ReduxCounterApp extends Component {
    render() {
        return (
            <div>
                <Label labelName = "Redux Counter App"/>
                 <h5> counterValue: {this.props.counterValue}</h5><br />
                <button className= "btn btn-primary" onClick={this.props.increment}>Increment Counter</button><br/><br/>
                <button className= "btn btn-primary" onClick={this.props.decrement}>Decrement Counter</button><br/><br/>
                <button className= "btn btn-primary" onClick={this.props.resetCounter}>Reset Counter</button><br/><br/>

            </div>
        );
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(ReduxCounterApp);