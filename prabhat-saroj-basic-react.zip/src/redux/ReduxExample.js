import React, { Component } from 'react';
import Label from '../components/Label';
import Nav from '../components/Nav';
import ReduxCounterApp from './ReduxCounterApp';

class ReduxExample extends Component {
    render() {
        return (
            <div>
                <Nav/>
                <Label labelName = "Redux Example"/>
                <ReduxCounterApp/>
            </div>
        );
    }
}

export default ReduxExample;