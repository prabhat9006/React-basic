const initiaValue = 0;

const counterReducer = (state = initiaValue, action)=>{
    switch (action.type) {

        case "INCREMEMT":
         return state + 1;

        case "DECREMENT":
           return state - 1;        
           
        case "RESETCOUNTER":
           return 0;

        default:
            return state;

    }
}

export default counterReducer;