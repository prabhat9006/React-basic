
import './App.css';
import RenderApp from './RenderApp';
function App() {
  return (
    <div className="App">
        <RenderApp />
    </div>
  );
}

export default App;
