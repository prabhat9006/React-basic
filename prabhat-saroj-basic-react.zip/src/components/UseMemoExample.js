import React, { useState, useMemo } from 'react';
import Label from './Label';
function useMemoExample() {

    const [count, setIncementCount] = useState(0);
    const [data, setData] = useState(10);

    const incrememtCount = () => {
        setIncementCount(count + 1);
    };
    const setDataValue = () => {
        setData(data + 2);
    };
    // const calculateData = () => {
    //     console.log("prabhat");
    //     return data * 2;
    // }
    const calculateDataMemo = useMemo(() => {
        console.log("prabhat");
        return data * 2;
    }, [data])

    return (
        <div>
            <Label labelName="UseMemo Hooks Example" />
            <h4>count : {count}</h4>
            <h4>Data : {data}</h4>
            <h4>calculateData : {calculateDataMemo}</h4>
            <button className="btn btn-primary" onClick={incrememtCount}> Incrememt</button><br /><br />
            <button className="btn btn-primary" onClick={setDataValue}> Upadte Data Value</button>
        </div>
    );
}

export default useMemoExample;