import React from "react";
import Label from "./Label";
import Nav from "./Nav";
function About() {
    return (
      <div className="App">
          <Nav/>
          <Label labelName = "This is About Us Page." />
      </div>
    );
  }

  export default About;