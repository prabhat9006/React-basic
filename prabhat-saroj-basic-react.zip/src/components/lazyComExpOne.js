import React from 'react';
import Label from './Label';


function LazyComExpOne() {
    return (
        <div>
        <div>
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
        </div>
        <div>
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
            <Label labelName="Lazy Component Example 1" />
        </div>
        </div>

    );
}

export default LazyComExpOne;