import React from "react";


class ChildCom extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            childCount: 0
        }
        this.setCountFromChild = this.setCountFromChild.bind(this);
    }
    setCountFromChild(){
        
        // this.setState({childCount: this.state.childCount + 1});
        // this.props.setCountFromChildMethod(this.state.childCount);
        
        this.props.setCountFromChildMethod();
    }
    render() {
        return (
            <div>
               <h2>Child class</h2>
                <button className="btn btn-primary" onClick={this.setCountFromChild}>Increase Count </button>
            </div>
        )
    }

}

export default ChildCom;