import React from "react"
import ReactTable from "react-table-6";
// import "react-table-v6/react-table.css";
import "react-table-6/react-table.css";


class ReactTableComponent extends React.Component {

    constructor(props){
        super(props)
        this.state = {
            data: [{
                name: 'Ayaan',
                age: 26
            }, {
                name: 'Ahana',
                age: 22
            }, {
                name: 'Peter',
                age: 40
            }, {
                name: 'Virat',
                age: 30
            }, {
                name: 'Rohit',
                age: 32
            }, {
                name: 'Dhoni',
                age: 37
            }],
            columns :  [{
                Header: 'Name',
                accessor: 'name'
            }, {
                Header: 'Age',
                accessor: 'age'
            }]
        }
    }

    render() {
        return (
            <div>
                <h5>Prabhat</h5>
                <ReactTable
                    data={this.state.data}
                    columns={this.state.columns}
                    defaultPageSize={2}
                    pageSizeOptions={[1,2, 4, 6]}
                />
            </div>
        )
    }
}
export default ReactTableComponent;
