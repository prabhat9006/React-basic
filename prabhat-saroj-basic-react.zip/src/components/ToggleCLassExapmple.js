import "../App.css";
import { useState } from "react";

function ToggleCLassExapmple() {
  const [toggleCLass, SetToggleClassNameValue] = useState(false);
  const toggleClassName = () => {
    SetToggleClassNameValue(!toggleCLass);
  };
  return (
    <div className="App">
      <h1 className={toggleCLass ? "red-text" : ""}>
        Hello CodeSandbox
      </h1>
      <button onClick={toggleClassName}> Toggle </button>
      <h2 >Start editing to see some magic happen!</h2>
    </div>
  );
}
export default  ToggleCLassExapmple;