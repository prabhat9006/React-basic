import React from "react";
import Label from "./Label";
function Error() {
    return (
        <div className="App">
            <Label labelName="Opps Something went wrong !!!" />
        </div>
    );
}

export default Error;