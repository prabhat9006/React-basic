import React from "react";
import Nav from "./Nav";
import ErrorBoundary from "./ErrorBoundary";
import BuggyCounter from "./BuggyCounter";

const url = `https://www.themealdb.com/api/json/v1/1/search.php?s=`;

class FoodList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            serachItem: "chicken",
            recipeList: [],
            showFoodList: false
        }
        this.onInputChange = this.onInputChange.bind(this);
        this.onSearchClick = this.onSearchClick.bind(this);
        this.getFoodList = this.getFoodList.bind(this);
    }

    getFoodList() {
        fetch(`${url}${this.state.serachItem}`).then((response) => {
            return response.json()
        }).then((res) => {
            if (res && res.meals) {
                this.setState({
                    recipeList: res.meals,
                    showFoodList: true
                })
            }
            else {
                this.setState({
                    recipeList: [],
                    showFoodList: false
                })
            }


        }).catch(function (error) {
            console.warn(error)
        })
    }
    onInputChange(event) {
        this.setState({ serachItem: event.target.value });
    }
    onSearchClick() {
        this.getFoodList();
    }
    componentDidMount() {
        this.getFoodList()
    }
    render() {
        const { showFoodList, recipeList } = this.state;
        return <>
            <Nav />
            <div className="jumbotron">

                <h1 className="display-2">
                    <span className="material-icons brand-icon">
                        fastfood
                    </span>
                    Food Recipe </h1>
                <div className="input-group w-50 mx-auto">
                    <input type="text" className="form-control" placeholder="Search Your Recipe..."
                        onChange={this.onInputChange}
                        value={this.state.serachItem} />
                    <div className="input-group-append">
                        <button className="btn btn-dark" onClick={this.onSearchClick}>Search Recipe</button>
                    </div>

                </div>
            </div>

            {!showFoodList ? <h1> No Recipe !!</h1> :
                <div className="card-columns">
                    {
                        recipeList.map((item, id) => (
                            <div className="card py-2 text-center" key={id + 1}>
                                <img src={item.strMealThumb} className="img-fluid w-50 mx-auto rounded-circle " />
                                <div className="card-body">
                                    <h5>{item.strMeal}</h5>
                                </div>
                                <ul className="list-group">
                                    <li className="list-group-item">{item.strIngredient1}</li>
                                    <li className="list-group-item">{item.strIngredient2}</li>
                                    <li className="list-group-item">{item.strIngredient3}</li>
                                    <li className="list-group-item">{item.strIngredient4}</li>
                                </ul>
                            </div>
                        ))
                    }

                </div>
            }
            <ErrorBoundary>
                <BuggyCounter />
            </ErrorBoundary>
        </>
    }

}


export default FoodList