import React from 'react';
import { useState } from 'react';
import MemoExample from './MemoExample';
export default function IncrementCounterApp() {
  const [count, setIncementCount] = useState(0);
  const [memoExampleData, setmemoExampleData] = useState([1,2,3,4]);

  const incrememtCount = () => {
    setIncementCount(count + 1);
  };
  const addMoreMemoExampleData = () => {
    setmemoExampleData([...memoExampleData, 6,7]);
  };


  return (
   
    <div>
      {count} <br /> <br />
      <button className="btn btn-primary" onClick={incrememtCount}> Incrememt</button>
        <MemoExample data={memoExampleData}/>
        <button className="btn btn-primary" onClick={addMoreMemoExampleData}> Upadte Memo Value</button>
    </div>
  );
}
