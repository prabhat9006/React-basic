import React, { Component } from 'react';
import Label from './Label';
import CounterApp from './CounterApp';
import CounterAppWithCss from './CounterAppWithCss';
import IncrementCounterApp from './IncrementCounterApp';
import HOCRed from './HOCRed';
import HOCBlue from './HOCBlue';
import HOCOrange from './HOCOrange';
class HocExample extends Component {
    render() {
        return (
            <div>
                <Label labelName = "HOC Example"/>
                {/* How to pass color individually. */}
                {/* <CounterAppWithCss color="red"/>
                <CounterAppWithCss color="green"/>
                <CounterAppWithCss color="blue"/>
                <CounterAppWithCss /> */}
                 <HOCRed cmp = {IncrementCounterApp} /><br/>
                 <HOCBlue cmp = {IncrementCounterApp} /><br/>
                 <HOCOrange cmp = {IncrementCounterApp} /><br/>
            </div>
        );
    }
}

export default HocExample;