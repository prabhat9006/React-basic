import React from "react";
import Label from "./Label";
import Nav from "./Nav";

function ContactUs() {
    return (
      <div className="App">
           <Nav/>
          <Label labelName = "This is Contact Page." />
      </div>
    );
  }

  export default ContactUs;