import React from 'react';
import Label from './Label';

function HOCRed(props) {
    return (
        <div style={{backgroundColor: 'red', width:200}}>
           <Label labelName = "HOC RED"/> 
             <props.cmp />
        </div>
    );
}

export default HOCRed;