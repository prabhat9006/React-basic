import React from 'react';
import { useState } from 'react';
import Label from './Label';
export default function CounterAppWithCss(props) {
  const [count, setIncementCount] = useState(0);
  const incrememtCount = () => {
    setIncementCount(count + 1);
  };
  const decrememtCount = () => {
    setIncementCount(count - 1);
  };
  const resetCount = () => {
    setIncementCount(0);
  };
  return (
    // <div style={{backgroundColor: props.color}}>
    <div>
      <Label labelName= "Hello Counter App!"/>
      {count} <br /> <br />
      <button style={{backgroundColor: props.color}} className="btn btn-primary" onClick={incrememtCount}> Incrememt</button>
      <br /><br />
      <button style={{backgroundColor: props.color}} className="btn btn-primary" onClick={decrememtCount}>Decrememt</button>
      <br /> <br />
      <button  style={{backgroundColor: props.color}} className="btn btn-primary" onClick={resetCount}> Reset</button>
    </div>
  );
}
