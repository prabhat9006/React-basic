import React, { Component } from 'react';  
import Label from './Label';
class ComponentLifeCycle extends React.Component {  
   constructor(props) {  
      super(props);  
      this.state = {
          hello: "React js Tutorial"
      };  
      this.changeState = this.changeState.bind(this)  
   }    
   render() {  
      return (  
         <>  
          <Label labelName = "ReactJS Component's Lifecycle"/> 
             <h3>Hello {this.state.hello}</h3>  
             <button className="btn btn-primary" onClick = {this.changeState}>Click Here!</button>          
         </>  
      );  
   }  
   componentDidMount() {  
      console.log('Component Did MOUNT!');  
   }  
   changeState(){  
       // Syntax
       //this.setState({property:value});  
      this.setState({hello:"All!!- Its a great reactjs tutorial."});  
   }  
   componentWillReceiveProps(newProps) {      
      console.log('Component Will Recieve Props!')  
   }  
   shouldComponentUpdate(newProps, newState) {  
    console.log('should Component Update method called!') 
      return true;  
   }  
   componentWillUpdate(nextProps, nextState) {  
      console.log('Component Will UPDATE!');  
   }  
   componentDidUpdate(prevProps, prevState) {  
      console.log('Component Did UPDATE!')  
   }  
   componentWillUnmount() {  
      console.log('Component Will UNMOUNT!')  
   }  
}  
export default ComponentLifeCycle;  
