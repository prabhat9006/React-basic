import React from 'react';
import Label from './Label';

function HOCOrange(props) {
    return (
        <div style={{backgroundColor: 'orange', width:200}}>
           <Label labelName = "HOC ORANGE"/> 
             <props.cmp />
        </div>
    );
}

export default HOCOrange;