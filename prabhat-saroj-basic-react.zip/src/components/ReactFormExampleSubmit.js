
import { useState, useRef } from "react";
import Label from "./Label"
export default function ReactFormExampleSubmit() {

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [show, setShowInput] = useState(false);

  const fNameRef = useRef();


  const ShowTheInput = (e) => {
    e.preventDefault();
    var fVal = e.target[0].value;
    var lVal = e.target[1].value;
    if (!fVal) return
    setFirstName(fVal);
    setLastName(lVal);
    setShowInput(true);
  };
  const ShowTheInputFrom = () => {
    setShowInput(false);
  };
  // const showDetials = () => {
  //   return <div>
  //           <h5>{firstName} {lastName}</h5>
  //           <button className="btn btn-primary" onClick={ShowTheInputFrom}>Show Form</button>
  //        </div>
  // }
  return (
    <div className="App">
      <Label labelName="React Form Example" />
      {show ? (<div>
            <h5>{firstName} {lastName}</h5>
            <button className="btn btn-primary" onClick={ShowTheInputFrom}>Show Form</button>
            {/* {showDetials()} */}
         </div>
      ) : (
        <div>
          <form onSubmit={ShowTheInput}>
            <input id="firstName" ref={fNameRef} placeholder="Enter First Name" />
            <br />
            <br />
            <input id="lastName" ref={fNameRef} placeholder="Enter Last Name" /> <br /><br />
            <button className="btn btn-primary">Submit</button>
          </form>
        </div>
      )
      }
    </div>
  );
}
