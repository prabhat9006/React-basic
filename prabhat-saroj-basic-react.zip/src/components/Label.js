import React from "react";
import PropsValidation from "./PropsValidation";

class Label extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            labelName: "Default Label Names"
        }
        // console.log(this);
        // console.log(this.props);
    }
    render() {
        // console.log(this);
        // console.log("this.props", this.props);
        // console.log("this.state ", this.state);
        return (
            <div style={{fontSize: "50px"}}>
                {/* <PropsValidation/> */}
                <h5>{this.props.labelName ? this.props.labelName : this.state.labelName}</h5>
            </div>
        )
    }

}

export default Label;