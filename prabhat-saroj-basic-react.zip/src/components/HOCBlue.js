import React from 'react';
import Label from './Label';

function HOCBlue(props) {
    return (
        <div style={{backgroundColor: 'blue', width:200}}>
           <Label labelName = "HOC BLUE"/> 
             <props.cmp />
        </div>
    );
}


export default HOCBlue;