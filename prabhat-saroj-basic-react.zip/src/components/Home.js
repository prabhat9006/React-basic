import React from "react";
import { Link } from "react-router-dom";
import Label from "./Label";
import Nav from "./Nav";
import ParentCom from "./ParentCom";
import ParentFun from "./ParentFun";
import HocExample from "./HocExample";
import ReactTableComponent from "./ReactTableComponent";
import CounterApp from "./CounterApp";
import ErrorBoundary from "./ErrorBoundary";
import BuggyCounter from './BuggyCounter';
import ReactFormExample from "./ReactFormExample";
import ReactFormExampleSubmit from "./ReactFormExampleSubmit";
import UnControlledComponentControlled from "./UnControlledComponentControlled";
import ToggleCLassExapmple from "./ToggleCLassExapmple";
import IncrementCounterApp from "./IncrementCounterApp";
import MemoExample from "./MemoExample";
import UniversityList from "./UniversityList";
import UniversityListEx from "./UniversityListEx";
import UseMemoExample from "./UseMemoExample";
function Home() {
  return (
    <div className="App">
      <Nav />
      <Label labelName="This is Home Page." />
      {/* <ParentCom /> */}
      {/* <ParentFun /> */}
      {/* <ReactTableComponent/> */}
      {/* <CounterApp/> */}
      {/* <HocExample/> */}
      {/* <ErrorBoundary>
        <BuggyCounter />
      </ErrorBoundary> */}
      {/* <ReactFormExample/> */}
      {/* <ReactFormExampleSubmit/>
      <UnControlledComponentControlled/> */}
      {/* <ToggleCLassExapmple/> */}
      {/* <IncrementCounterApp/> */}
      {/* <UniversityList/> */}
        {/* <UniversityListEx/> */}
        <UseMemoExample/>
    </div>
  );
}
 
export default Home;