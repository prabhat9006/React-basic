import React, { Component } from 'react';
import Label from './Label';
class CounterAppClass  extends Component {
    constructor(props){
        super(props)
        this.state = {
            incrementCounter : 0,
            decrementCounter : 0
        };
        this.incrementCount = this.incrementCount.bind(this);
        this.decrementCount = this.decrementCount.bind(this);
        this.resetCount = this.resetCount.bind(this);
    }
    incrementCount() {
        this.setState({ incrementCounter: this.state.incrementCounter + 1 })
    }
    decrementCount() {
        this.setState({ decrementCounter: this.state.decrementCounter - 1 })
    }
    resetCount() {
        this.setState({ incrementCounter: 0 })
        this.setState({ decrementCounter: 0 })
    }
    render() {
        return (
            <div>
                <Label labelName = "Redux Counter App"/>
                <h5>{this.state.incrementCounter}</h5>
                <button className= "btn btn-primary" onClick={this.incrementCount}>Increment Counter</button><br/><br/>
                <h5>{this.state.decrementCounter}</h5>
                <button className= "btn btn-primary" onClick={this.decrementCount}>Decrement Counter</button><br/><br/>
                <button className= "btn btn-primary" onClick={this.resetCount}>Reset Counter</button>
            </div>
        );
    }
}
export default CounterAppClass ;