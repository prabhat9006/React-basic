import React, { Component, memo} from 'react';
import Label from './Label';
class MemoExample extends Component {
    constructor(props){
        super(props)
    }
    render() {
        console.log(this.props.data);
        return (
            <div>
              <Label labelName="Memo Example"/>
            </div>
        );
    }
}

export default memo(MemoExample);