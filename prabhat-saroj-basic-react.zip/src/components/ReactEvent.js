import React, { Component } from 'react';  

class ReactEvent extends Component {  
    constructor(props) {  
        super(props);  
        this.state = {  
            companyName: ''  
        }; 
     this.changeText = this.changeText.bind(this); 
    }  
    changeText(event) {  
        console.log(event.target.value);
        this.setState({  
            companyName: event.target.value  
        });  
    }

 // Here this will refer to class scope (parent scope)
    // changeText = (event) => {
    //     this.setState({
    //         companyName: event.target.value
    //     });
    // }
    
    render() {  
        return (  
            <div>  
                <h2>Simple Event Example by class component</h2>  
                <label htmlFor="name">Enter company name: </label>  
                {/* Method one */}
                {/* <input type="text" id="companyName" onChange={this.changeText.bind(this)}/>   */}
              
                {/* Method two */}
                <input type="text" id="companyName" onChange={this.changeText}/>  
                
                <h4>You entered: { this.state.companyName }</h4>  
            </div>  
        );  
    }  
}  
export default ReactEvent;  