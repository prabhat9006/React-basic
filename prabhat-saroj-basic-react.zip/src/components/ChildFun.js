import React from "react";

export default function ParentFun(props) {

  const setCountFromChild = () => {
    props.setCountFromChildMethod();
  };

  return (
    <div className="App">
      <h5>Hello  Child Functional Component</h5>
      <button className = "btn btn-primary" onClick={setCountFromChild}>Increase Count </button>
    </div>
  );
}
