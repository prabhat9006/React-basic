
import { useState, useRef } from "react";
import Label from "./Label"
export default function ReactFormExample() {

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [fulltName, setFullName] = useState("");
  const [show, setShowInput] = useState(false);



  const setFirstNameValue = (e) => {
    let value = e.target.value;
    setFirstName(value);
  };
  const setLastNameValue = (e) => {
    let value = e.target.value;
    setLastName(value);
  };
    const ShowTheInput = (e) => {
        e.preventDefault();
        var fVal = e.target[0].value;
        var lVal = e.target[1].value;
        if(!fVal) return 
        var fullName = fVal + " "+  lVal;
        setFullName(fullName);
        setShowInput(true);
    };
    const ShowTheInputFrom = () => {
        setShowInput(false);
    };
  return (
    <div className="App">
     <Label labelName = "React Form Example"/>
      {show ? (<div>
        {/* <h5>{fulltName}</h5> */}
        <h5>{firstName} {lastName}</h5>
        <button className="btn btn-primary" onClick={ShowTheInputFrom}>Show Form</button>
        </div>
        
      ) : (
        <div>
          <form onSubmit={ShowTheInput}>
            <input id="firstName" value={firstName} placeholder="Enter First Name" onChange={setFirstNameValue} />
            <br/>
            <br/>
            <input id="lastName" value={lastName} placeholder="Enter Last Name"  onChange={setLastNameValue} /> <br/><br />
            <button className="btn btn-primary">Submit</button>
          </form>
        </div>
      )}
    </div>
  );
}
