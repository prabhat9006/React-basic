import React, { useState } from 'react';

function ReactEventFun() {
  const [companyName, setcompanyName] = useState("");

  // function changeText(event) {
  //   setcompanyName(event.target.value);
  // }

  const changeText = (event)=> {
    setcompanyName(event.target.value);
  }

  return (
    <div className="App">
      <div>
        <h2>Simple Event Example by functional component</h2>
        <label htmlFor="name">Enter company name: </label>
        {/* Methos one */}
        <input type="text" id="companyName" onChange={changeText} />

         {/* Methos Two */}
        {/* <input type="text" id="companyName" onChange={(event)=> setcompanyName(event.target.value)} /> */}
        <h4>You entered: {companyName}</h4>
      </div>
    </div>
  )
}
export default ReactEventFun;