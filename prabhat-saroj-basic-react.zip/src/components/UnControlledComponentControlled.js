
import React from "react";

class UnControlledComponentControlled extends React.Component {

    constructor(props) {
      super(props);
      this.inputFirst = React.createRef();
      this.inputLast = React.createRef();
      this.handleSubmit = this.handleSubmit.bind(this);
    }

  
    handleSubmit(event) {
      alert('A name was submitted: ' + this.inputFirst.current.value);
      alert('A name was submitted: ' + this.inputFirst.current.focus());      
      alert('A name was submitted: ' + this.inputLast.current.value);
      alert('A name was submitted: ' + this.inputLast.current.focus());
      event.preventDefault();
    }
  
    render() {
      return (
        <>
       <h3>UnControlled Component Controlled</h3>
        <form onSubmit={this.handleSubmit}>
          <label>
            Name:
            <input id="firstName" type="text" ref={this.inputFirst} />
            <input  id="lastName" type="text" ref={this.inputLast} />
          </label>
          <input type="submit" value="Submit" />
        </form>
        </>
      );
    }
  }

  export default UnControlledComponentControlled;