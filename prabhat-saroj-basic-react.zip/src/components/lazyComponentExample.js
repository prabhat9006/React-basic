import React, { Suspense, lazy } from 'react';
import Label from './Label';
import Nav from './Nav';
// import LazyComExpOne from './lazyComExpOne';
// import LazyComExpTwo from './lazyComExpTwo';
const LazyComExpOne = lazy(() => import("./lazyComExpOne"));
const LazyComExpTwo = lazy(()=> import("./lazyComExpTwo"));
function LazyComponentExample() {
    return (
        <div>
            <Nav />
            <Label labelName="Lazy Component Header" />
            <Suspense fallback={<div>Please Wait .... LazyComExpOne is loading.</div>}>
                <LazyComExpOne />
               
            </Suspense>
            <Suspense fallback={<div>Please Wait .... LazyComExpTwo is loading.</div>}>
                <LazyComExpTwo />
            </Suspense>
            {/* <LazyComExpTwo /> */}
        </div>
    );
}

export default LazyComponentExample;