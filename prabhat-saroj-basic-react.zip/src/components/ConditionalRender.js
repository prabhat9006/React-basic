
import Label from './Label';
import ComponentLifeCycle from './ComponentLifeCycle';

import {useState} from 'react';


function ConditionalRender() {

  const [show , updateShow] = useState(true);

  const changeState = () => {
    updateShow(!show);
  }

  return (
    <>
      <Label labelName = "React Js Conditional Render"/>
        <button className="btn btn-primary" onClick = {changeState}>Remove Life cycle method</button>          
       {
         show ? <ComponentLifeCycle/> : "Component Life Cycle Umount !!" 
       } 

    </>
  );
}

export default ConditionalRender;
