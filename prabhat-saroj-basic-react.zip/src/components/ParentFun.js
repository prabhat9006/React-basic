import { React, useState } from "react";
import Child from "./ChildFun";

export default function ParentFun() {

    // var [limit, setCount] = useState(0);
    const [count, setCount] = useState(0);

    const setCountFromChild = () => {
        // setCount(limit++); // No error
       //  setCount(count++);  // error count = count + 1 //TypeError: Assignment to constant variable.
    
       setCount(count + 1);
    };

    return (
        <div className="App">
             <h5>Hello  ParentFun Functional Component</h5>
            {count}
            <Child setCountFromChildMethod={ParentFun} />
        </div>
 );
}


