import { Component, React, useState } from "react";
import ChildCom from "./ChildCom";
export default class ParentCom extends Component {
    constructor(props){
        super(props)
        this.state = {
            count: 0
        }
        this.setCountForParent = this.setCountForParent.bind(this);
    }
    setCountForParent = (cnt) => {
       this.setState({count: this.state.count + 1})
    //    this.setState({count: this.state.count + cnt})
    }
    render() {
        return (
            <div className="App">
                
                <h2>Parent class</h2>
                {this.state.count}
                <ChildCom setCountFromChildMethod={this.setCountForParent} />
            </div>);
    }

}

