import React, { useState, useEffect } from 'react';
import Label from './Label';
function UniversityList() {
    const [universityRecords, setUniversityRecords] = useState([]);
    const [ShowUniversityRecords, setshowUniversityRecords] = useState(false);

    useEffect(() => {
        fetch("http://universities.hipolabs.com/search?country=United+States").then((res) => {
            return res.json();
        }).then((data) => {
            console.log(data);
            setUniversityRecords(data);
            //setshowUniversityRecords(true);
        })
    }, [])
    return (
        <div>
            <Label labelName="List of Universites !! " />
            {ShowUniversityRecords ? <div> Please Wait ... !!!</div>

                :
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">University Name</th>
                            <th scope="col">country</th>
                            <th scope="col">Domains</th>
                            <th scope="col">contact us</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            universityRecords.map((item, index) => (
                                <tr key={index + 1}>
                                    <th scope="row">{index}</th>
                                    <th scope="row">{item.name}</th>
                                    <td>{item.country}</td>
                                    <td>{item.domains[0]}</td>
                                    <td><a href={item.web_pages} target="_blank">Visit This University</a></td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>

            }
        </div>
    );
}

export default UniversityList;