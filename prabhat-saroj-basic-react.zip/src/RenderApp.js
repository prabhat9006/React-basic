
import {Routes,Route} from "react-router-dom";
import About from './components/About';
import ContactUs from './components/ContactUs';
import Error from './components/Error';
import Home from './components/Home';
import FoodList from './components/FoodList';
import LazyComponentExample from './components/lazyComponentExample';
import ReduxExample from './redux/ReduxExample';
function RenderApp() {

  return (
    <>
       <Routes>
         <Route path="/" element = {<Home/>}/>
         <Route path="/reduxexample" element = {<ReduxExample/>}/>
         <Route path="/about" element = {<About/>}/>
         <Route path="/contact" element = {<ContactUs/>}/>
         <Route path="/foodlist" element = {<FoodList/>}/>
         <Route path="/lazycomponentexample" element = {<LazyComponentExample/>}/>
         <Route path="*" element = {<Error/>}/>
       </Routes>
    </>
  );
}

export default RenderApp;
