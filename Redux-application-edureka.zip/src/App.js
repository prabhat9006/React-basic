import { BrowserRouter, Routes, Route } from "react-router-dom";
import Enquiry from "./component/enquiry";
import ProjectTitle from "./component/projectTitle";
import EnquiryList from "./component/enquiryList";
import CourseList from "./component/courseList";
function App() {
  return (
    <div className="container">
      <BrowserRouter>
        <ProjectTitle />
        <Routes>
          <Route path="/" element={<CourseList/>}></Route>
          <Route path="/enquiries" element={<Enquiry/>}></Route>
          <Route path="/enquirylist" element={<EnquiryList/>}></Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
