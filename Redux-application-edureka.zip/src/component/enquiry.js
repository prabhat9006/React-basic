
import React, { Component } from "react";

import EnquiryList from "./enquiryList";
import { addEnquiry } from './action/coursesActions';
import { connect } from 'react-redux';

const mapDispatchToProps = (dispatch, enquiryList) => {
    return {
        addEnquiry: (enquiryList) => dispatch(addEnquiry(enquiryList))
    }
}
const mapStateToProps = (props) => {
    return {
        showSubmitedRecord: props.courseData.showSubmitedRecord
    }
}

class enquiry extends Component {
    saveEnquirie = (e) => {
        e.preventDefault();
        console.log(e)
        var data = {}
        data.firstName = e.currentTarget.elements["exampleInputfirstName"].value;
        data.lastName = e.currentTarget.elements["exampleInputLastName"].value;
        data.phoneNumber = e.currentTarget.elements["exampleInputPhone"].value;
        data.courseName = e.currentTarget.elements["exampleInputCouse"].value;
        data.email = e.currentTarget.elements["exampleInputEmail1"].value;
        console.log(data);
        this.props.addEnquiry(data)
    }
    render() {
        return (
            <div className="container">
                <h1>Enquiries:</h1>
                {this.props.showSubmitedRecord ? <EnquiryList />:
                <form onSubmit={this.saveEnquirie}>
                    <div className="form-group">
                        <label >First Name</label>
                        <input type="text" className="form-control" id="exampleInputfirstName" placeholder="Enter Your First Name"></input>
                    </div><br></br>
                    <div className="form-group">
                        <label >Last Name</label>
                        <input type="text" className="form-control" id="exampleInputLastName" placeholder="Enter Your Last Name"></input>
                    </div><br></br>
                    <div className="form-group">
                        <label >Phone Number</label>
                        <input type="tel" pattern="[0-9]{10}" maxLength="10" name="phone"  className="form-control" id="exampleInputPhone" placeholder="Enter Your Phone Number"></input>
                    </div><br></br>
                    <div className="form-group">
                        <label >Course Title</label>
                        <input type="text" className="form-control" id="exampleInputCouse" placeholder="Enter Your Course"></input>
                    </div><br></br>
                    <div className="form-group">
                        <label >Email address</label>
                        <input type="email" className="form-control" id="exampleInputEmail1" placeholder="Enter Your email"></input>
                    </div>
                     <br></br>
                     <br></br>
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
                }
            </div>
        )
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(enquiry);
