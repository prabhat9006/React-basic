import courseData from "./courseData";

import {combineReducers} from "redux";


const rootReducer = combineReducers({
   courseData
})
export default rootReducer;