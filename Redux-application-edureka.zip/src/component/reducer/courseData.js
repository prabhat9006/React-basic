
const courseData = (state = {}, action) => {

    switch (action.type) {
        case 'DISPLAY_COURSE_RECORDS':
            return { ...state, courseListRecord: action.payload }
        case 'ADD_COURSE_RECORDS':
            return { ...state, addCourseRecord: action.payload, showSubmitedRecord: true }
        case 'DISPLAY_ENQUIRY_RECORDS':
            return { ...state, enquiryListRecord: action.payload , showEnquiryListRecord: false}
        default:
            return state;

    }
}
export default courseData;