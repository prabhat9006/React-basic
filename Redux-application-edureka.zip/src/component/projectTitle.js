import React, { Component } from 'react';
import { Link } from "react-router-dom";

class ProjectTitle extends Component {
    render() {
        return (

            <div className="container">
                <nav className="navbar navbar-expand-lg navbar navbar-dark bg-primary">
                    <div className="container-fluid">

                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                                <li className="nav-item">
                                    <Link to='/' className="nav-link active" >Home</Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link active" to='/enquiries'>Enquiries</Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link active" to='/enquirylist'>Enquiry List</Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <h5>Course List Application using Redux.</h5>
                <p>Build a course list application with React, Reduxand Rest API. Follow the below mentioned steps to build the application.</p>

                <h5>1.Make use of JSON server to create a static API (containing courses JSON data). Create a separate action for calling API.</h5>
                <h5>2.Under each course there must be enquire button.</h5>
                <h5>3.On clicking enquire button, a form should be displayed. Here user should be able to type their details.</h5>
                <h5>4.On clicking the submit button the user information should be added to json file.</h5>
                <h5>5.Also create one more tab-‘Enquires’ where users can leave their details to clear their doubts.</h5>
                <h5>6.Make use of reducer to maintain the state of application.</h5>


            </div>
        );
    }
}

export default ProjectTitle;