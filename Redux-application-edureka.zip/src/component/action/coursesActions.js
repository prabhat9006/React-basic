import axios from "axios";
const url2 = "http://localhost:3002/courseList";
const url = "http://localhost:3002/enquiries";


export const fetchCourseList = () => {
    return dispatch => {
        axios.get(url2).then(response => {
        dispatch({
            type: "DISPLAY_COURSE_RECORDS",
            payload: response.data
        });
      });
    };
  };

export const addEnquiry = (props) => {
    return dispatch => {
        axios.post(url, props).then(response => {
        dispatch({
            type: "ADD_COURSE_RECORDS",
            payload: response.data
        });
      });
    };
  };


  export const getEnquiryList = () => {
    return dispatch => {
        axios.get(url).then(response => {
        dispatch({
            type: "DISPLAY_ENQUIRY_RECORDS",
            payload: response.data
        });
      });
    };
  };