import React, { Component } from 'react';
import { Link } from "react-router-dom";
import { fetchCourseList } from './action/coursesActions';
import { connect } from 'react-redux';

const mapDispatchToProps = (dispatch) => {
    return {
        fetchCourseList: () => dispatch(fetchCourseList())
    }
}
const mapStateToProps = (props) => {
    return {
        courseList: props.courseData.courseListRecord
    }
}

class CourseList extends Component {

    componentDidMount() {
        this.props.fetchCourseList();
    }

    render() { 
        
        return (
            <div>
                {!this.props.courseList ?<h1>No CourseList Available !!!</h1> :
                    <div>
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">CourseId </th>
                                    <th scope="col">Course Title</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Fee</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                   this.props.courseList.map((myvariables, id) => (
                                        <tr key={id + 1}>
                                            <th value={id + 1} scope="row">{id + 1}</th>
                                            <td value={myvariables.courseId}>{myvariables.courseId}</td>
                                            <td value={myvariables.title}>{myvariables.title}</td>
                                            <td value={myvariables.description}>{myvariables.description}</td>
                                            <td value={myvariables.fee}>{myvariables.fee}</td>
                                            <td value={myvariables.courseId}><Link to="/enquiries" value={myvariables.courseId} className="btn btn-primary">Enquire</Link></td>
                                        </tr>


                                    ))

                                }
                            </tbody>
                        </table>

                    </div>
                }
            </div>
        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(CourseList);