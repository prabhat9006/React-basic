import React, { Component } from 'react';
import { getEnquiryList } from './action/coursesActions';

import { connect } from 'react-redux';


const mapDispatchToProps = (dispatch)=>{
    return {
        getEnquiryList : ()=> dispatch(getEnquiryList())
    }

}

const mapStateToProps = (props) =>{
    return {
        enquiryList : props.courseData.enquiryListRecord ? props.courseData.enquiryListRecord : [],
        showEnquiryListRecord : props.courseData.showEnquiryListRecord ? props.courseData.showEnquiryListRecord : true,
    }

}
class EnquiryList extends Component {
    componentDidMount() {
        this.props.getEnquiryList();
    }
    render() {
        if (this.props.showEnquiryListRecord && this.props.enquiryList.length == 0)
            return <h1>No EnquiryList Available !!!</h1>
        return (
            <div>
                {
                    <div>
                        <h3>User Enquiry List</h3>
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">FirstName</th>
                                    <th scope="col">LastName</th>
                                    <th scope="col">PhoneNumber </th>
                                    <th scope="col">CourseName </th>
                                    <th scope="col">Email</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                   this.props.enquiryList.map((myvariables, id) => (
                                        <tr key={id + 1}>
                                            <th value={id + 1} scope="row">{id + 1}</th>
                                            <td value={myvariables.courseId}>{myvariables.firstName}</td>
                                            <td value={myvariables.courseId}>{myvariables.lastName}</td>
                                            <td value={myvariables.title}>{myvariables.phoneNumber}</td>
                                            <td value={myvariables.title}>{myvariables.courseName}</td>
                                            <td value={myvariables.title}>{myvariables.email}</td>
                                        </tr>
                                    ))
                                }
                            </tbody>
                        </table>

                    </div>
                }
            </div>
        );
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(EnquiryList);