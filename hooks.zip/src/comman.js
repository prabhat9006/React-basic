import { useEffect} from 'react'

function Comman(counter) {
    useEffect(() => {
        document.title =  `${counter}`
    })
}
export default Comman;