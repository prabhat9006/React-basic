import { useEffect, useState } from 'react'
import Comman from './comman';
function Two() {
    const [counter, setCounter] = useState(0);
    Comman(counter);
    return (
        <div className="container">
            <button className="btn btn-primary" onClick={
                () =>
                    setCounter(counter + 1)}>
                Click Here to Increment Counter</button>
        </div>
    )
}

export default Two;
