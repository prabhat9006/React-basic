import React from 'react';
import ReactDOM from 'react-dom';
import AppClass from './AppClass';
import AppFunctionHooks from './AppFunctionHooks';
import Datafromapi from './Datafromapi';
import One from './One';
import Two from './Two';
import reportWebVitals from './reportWebVitals';

ReactDOM.render(
  <React.StrictMode>
    {/* <AppClass /> */}
    {/* <AppFunctionHooks /> */}
    {/* <Datafromapi /> */}
    <One />
    <Two />
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
