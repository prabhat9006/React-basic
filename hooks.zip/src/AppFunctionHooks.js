import { useState } from "react";

function AppFunctionHooks() {
  const [counter, setCounter] = useState(0)
  return (
    <div className="container">
      <h1>counter using Hooks</h1>
      <h1>{counter}</h1>
      <button className="btn btn-primary" onClick={
        () =>
          setCounter(counter + 1)}>
        Click Here to Increment Counter
      </button>
      <br />
      <br />
      <button className="btn btn-primary" onClick={
        () =>
          setCounter(counter - 1)}>
        Click Here to decrement Counter</button>
    </div>
  )
}
export default AppFunctionHooks;