import React, { useEffect, useState } from 'react'
import axios from 'axios';

function Datafromapi() {

    const [myitems, setmyitems] = useState([])

    useEffect(() => {
        axios.get("https://jsonplaceholder.typicode.com/albums")
            .then((myjson) => {
                console.log(myjson)
                setmyitems(myjson.data)
                // this.setState({
                //     myitems: myjson.data
                // })
            }).catch((err) => {
                console.log(err)
            })
    })

    return (
        <div class="container">
            {
                myitems.map((myvariables) => (
                    <p key={myvariables.id}>{myvariables.userId},{myvariables.title}</p>
                ))
            }
        </div>
    )
}

export default Datafromapi