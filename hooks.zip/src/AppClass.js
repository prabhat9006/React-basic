import React from "react";

class AppClass extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      counter: 0
    }
  }
  render() {
    return (
      <div className="container">
         <h1>counter using Class Component</h1>
        <h1>{this.state.counter}</h1>
        <button className= "btn btn-primary" onClick={
          () =>
            this.setState({ counter: this.state.counter + 1 })}>
          Click Here to Increment Counter</button>
          <br/>
          <br/>
        <button className= "btn btn-primary"  onClick={
          () =>
            this.setState({ counter: this.state.counter - 1 })}>
          Click Here to decrement Counter</button>
      </div>
    )
  }
}
export default AppClass;