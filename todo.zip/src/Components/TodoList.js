import React from "react";

class TodoList extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            myitems: []
        }
    }


    render() {
        let { myitems, showList } = this.state

        function uncheckedItems() {
            myitems = [];
            const elms = document.querySelectorAll("input[type='checkbox']");
            elms.forEach(element => {
                if (element.checked) {
                    element.checked = false
                }
            });
        }
        function addToCart(element) {
            myitems.push(element.target.value)
        }

        function showCart() {
            return (
                <div>{
                    myitems.forEach(element => {
                        // <h1>element</h1>
                        document.writeln(element)
                    })
                }
                </div>
            )
        }
        return (
            <div className="container">
                <h1>TodoList</h1>
                <input type="checkbox" id="fish" name="fish" value="Fish" onClick={addToCart} /> Fish<br />
                <input type="checkbox" id="tomato" name="tomato" value="tomato" onClick={addToCart} /> Tomato <br />
                <input type="checkbox" id="potato" name="potato" value="Potato" onClick={addToCart} /> Potato<br />
                <input type="checkbox" id="potato" name="potato" value="Potato" onClick={addToCart} /> Potato<br />
                <input type="checkbox" id="curd" name="curd" value="curd" onClick={addToCart} /> Curd<br />
                <input type="checkbox" id="onion" name="onion" value="Onion" onClick={addToCart} /> Onion<br /><br />
                <input className="btn btn-primary" type="submit" id="submit" name="submit" onClick={showCart} value="submit" />
                <input className="btn btn-primary" type="submit" id="clear" name="clear" onClick={uncheckedItems.bind(this)} value="Clear" />
                
            </div>

        )
    }
}

export default TodoList;