export function latestdata() {
    const mydata = fetch(`http://universities.hipolabs.com/search?country=United+States`,
        { method: 'GET' })
        .then(
            res => res.json()
        )
    return {
        type: 'NEW_ARTICLES',
        payload: mydata
    }
}