import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import reportWebVitals from './reportWebVitals';

// import mystore from 'redux'
// mystore.createStore
// mystore.applyMiddleware

import { createStore, applyMiddleware } from 'redux'
import mypromiseMiddleware from 'redux-promise'
import { Provider } from 'react-redux'
import myreducer from './reducers'

const mystore = applyMiddleware(mypromiseMiddleware)(createStore)
//applymiddleware - it binds or wraps the store with the promise middleware
//redux-promise - Its a promise which returns the object upon resolve (check what happenes when
//the reject is implemented)
//ceratestore - creates the store
//provider - connects teh states of the componentst with the store and vice versa
ReactDOM.render(
  <Provider store={mystore(myreducer)}>
    <App />
  </Provider>,
  document.getElementById('root')
);
//store = attribute which accepts the store as a 1st parameter
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();