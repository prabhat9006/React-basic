import { BrowserRouter, Route, Routes} from 'react-router-dom';
import Header from './component/Header';
import Footer from './component/Footer';

import Body from './container/Body'

function App() {
  return (
    <BrowserRouter>
     <Header />
    <Routes>
      <Route exact path="/" element={<Body />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
}

export default App;