import React from 'react';

const Header = () => {
    return (
        <div>
          <h1>header</h1>
        </div>
      );
}
export default Header;