import React from 'react'

const consoledata = (mydata) => {
    debugger   //display the data in console.
    console.log(mydata)
}
function isEmptyObject(value) {
    return Object.keys(value).length === 0 && value.constructor === Object;
  }
const Content = (props) => {
    const { latestcontent } = props   //accessing from body
    if (isEmptyObject(latestcontent)) {
        return <div>Data Not Available.</div>
    }
    return (
        <div className="container">
            {consoledata(props)}

            {
                // latestcontent.mylateststate.map((myvariables, id) => (
                //     // <p key={myvariables.id}>{myvariables.userId} , {myvariables.id}, {myvariables.title}</p>
                //     <p id={id + 1} key={id + 1}>{id + 1}. {myvariables.author} , {myvariables.message}, {myvariables.title}, {myvariables.date}</p>
                // ))

                <div>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">country </th>
                            <th scope="col">Name</th>
                            <th scope="col">domains</th>
                            {/* <th scope="col">Date</th> */}
                        </tr>
                    </thead>
                    <tbody>
                            {
                                latestcontent.mylateststate.map((myvariables, id) => (
                                    <tr key={id+1}>
                                        <th scope="row">{id + 1}</th>
                                        {/* <td>{myvariables.author}</td>
                                        <td>{myvariables.message}</td>
                                        <td>{myvariables.title}</td>
                                        <td>{myvariables.date}</td>                                        <td>{myvariables.author}</td> */}
                                        <td>{myvariables.country}</td>
                                        <td>{myvariables.name}</td>
                                        <td>{myvariables.domains[0]}</td>
                                        </tr>
                                    
                                ))
                            }
                    </tbody>
                </table>
            </div>
            }
        </div>
    )
}

export default Content