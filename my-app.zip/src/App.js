// import Header from './component/Header';
// import Content from './component/Content';
// import Footer from './component/Footer';
// import FooterClass from './component/FooterClass';
// import FooterClasswillUnmount from './component/FooterClasswillUnmount';
// import Login from './component/Login';

import Homepage from './component/Homepage';
// import Loginpage from './component/Loginpage';
// import Registerpage from './component/Registerpage';

function App() {
  return (
    <div>
      {/* <Header/> */}
      {/* <Login/> */}
      <Homepage />
      {/* <Loginpage /> */}
      {/* <Registerpage /> */}
      {/* <Content/> */}
      {/* <Footer/> */}
      {/* <FooterClass/> */}
      {/* <FooterClasswillUnmount/> */}
    </div>
  );
}

export default App;
