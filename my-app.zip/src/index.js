import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Homepage from './component/Homepage';
import Loginpage from './component/Loginpage';
import Datafromapi from './component/Datafromapi';
import Registerpage from './component/Registerpage';
import MyLoginIdPage from './component/MyLoginIdPage';
import Nopage from './component/Nopage';
import reportWebVitals from './reportWebVitals';
import App from './App';

import { BrowserRouter, Routes, Route } from 'react-router-dom'

const myroute = (
  <BrowserRouter>
    <div>
      <Routes>
        <Route exact path="/" element={<Homepage />} />
        <Route path="/login" element={<Loginpage />} />
        <Route path="/apidata" element={<Datafromapi />} />
        <Route path="/login/:myloginid" element={<MyLoginIdPage/>} />
        <Route path="/register" element={<Registerpage />} />
        <Route path="/app" element={<App />} />
        <Route path="/*" element={<Nopage />} />
      </Routes>
    </div>
  </BrowserRouter>
)

ReactDOM.render(
  myroute,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();