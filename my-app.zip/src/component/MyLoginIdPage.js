import React from "react";

class MyLoginIdPage extends React.Component{
   constructor(){
       super();
       this.state = {
        myloginid : ""
       }
   }
    componentDidMount(){
        console.log(this.props)
        //console.log(this.props.match.params.myloginid)
    }
    render(){
        return(
            <div>Name : { this.myloginid }</div>
        )
    }
}

// import { useParams } from 'react-router-dom';

// const MyLoginIdPage = () => {
//     const { myloginid } = useParams();

//     return (
//         <div>Name : { myloginid }</div>
//     );
// }

export default MyLoginIdPage;