import React from "react";

class Login extends React.Component {
    constructor() {
        super();
        this.state = {
            myvalue1: "",
            myvalue2: ""
        }
    }
    mytrigger1 = (event) => {
        this.setState({ myvalue1: event.target.value })
    }

    mytrigger2 = (event) => {
        const last = event.target.value;
        if (last != "sinha") {
            console.log("Hi Sinha !");
        }
        this.setState({ myvalue2: event.target.value })
    }
    render() {
        return (
            < div >
                <form>
                    <input type="text"
                        placeholder="Enter Your Text Here"
                        onChange={this.mytrigger1}>
                    </input>
                    <br></br>
                    <br></br>
                    <br></br>
                    <input type="text"
                        placeholder="Enter Your second Text Here"
                        onChange={this.mytrigger2}>
                    </input>
                </form>

                 <p>{this.state.myvalue1} {this.state.myvalue2}</p>
                 <p style={{color: "red" , backgroundColor: "blue"}}>{this.state.myvalue2}</p>

            </div >

        )
    }
}
export default Login;