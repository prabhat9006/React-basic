import React from 'react'
import axios from 'axios'
import Homepage from './Homepage';
class Datafromapi extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            myitems: []
        }
    }

    componentDidMount() {
        axios.get("http://universities.hipolabs.com/search?country=United+States")
        // axios.get("http://localhost:3001/data")
            .then((myjson) => {
                debugger
                this.setState({
                    myitems: myjson.data
                })
            }).catch((err) => {
                console.log(err)
            })
    }

    render() {
        const { myitems } = this.state
        return (
            <div className="container">
                <Homepage />
                <h1>List Of USA Universities</h1>
                {
                    // myitems.map((myvariables, id) => (
                    // <p key={myvariables.id}>{myvariables.userId}, {myvariables.id}, {myvariables.title}</p>
                    // <p id= {id+1} key={id+1}>{id+1}. {myvariables.alpha_two_code} , {myvariables.name}, {myvariables.domains[0]}</p>

                    <div>
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Country Code </th>
                                    <th scope="col">Name of University</th>
                                    <th scope="col">Domains</th>
                                </tr>
                            </thead>
                            <tbody>
                                    {
                                        myitems.map((myvariables, id) => (
                                            <tr key={id+1}>
                                                <th scope="row">{id + 1}</th>
                                                <td>{myvariables.alpha_two_code}</td>
                                                <td>{myvariables.name}</td>
                                                <td>{myvariables.domains[0]}</td>
                                                </tr>
                                            
                                        ))
                                    }
                            </tbody>
                        </table>
                    </div>
                // ))

            //         <div>
            //         <table className="table table-striped">
            //             <thead>
            //                 <tr>
            //                     <th scope="col">#</th>
            //                     <th scope="col">First Name </th>
            //                     <th scope="col">Lirst Name</th>
            //                     <th scope="col">Email</th>
            //                 </tr>
            //             </thead>
            //             <tbody>
            //                     {
            //                         myitems.map((myvariables, id) => (
            //                             <tr key={id+1}>
            //                                 <th scope="row">{id + 1}</th>
            //                                 <td>{myvariables.first_name}</td>
            //                                 <td>{myvariables.last_name}</td>
            //                                 <td>{myvariables.email}</td>
            //                                 </tr>
                                        
            //                         ))
            //                     }
            //             </tbody>
            //         </table>
            //     </div>



            
             }
            </div>
        )
    }
}

export default Datafromapi