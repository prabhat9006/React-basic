import React from "react";

function Nopage() {
return(
    <div>This is no Page</div>
)
}
export default Nopage;