import { Component } from 'react';
import img1 from './images/wall1.jpeg';
import img2 from './images/wall2.jpeg';
import img3 from './images/wall3.jpeg';

// className Content extends Component {
//   render(){
//   return (
//     <div>
//       <div id="carouselExampleInterval" classNameName="carousel slide" data-bs-ride="carousel">
//         <div classNameName="carousel-inner">
//           <div classNameName="carousel-item active" data-bs-interval="10000">
//             <img src = {img1} classNameName="d-block w-100" alt="..."></img>
//           </div>
//           <div classNameName="carousel-item" data-bs-interval="2000">
//             <img  src = {img2} classNameName="d-block w-100" alt="..."></img>
//           </div>
//           <div classNameName="carousel-item">
//             <img  src = {img3} classNameName="d-block w-100" alt="..."></img>
//           </div>
//         </div>
//         <button classNameName="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
//           <span classNameName="carousel-control-prev-icon" aria-hidden="true"></span>
//           <span classNameName="visually-hidden">Previous</span>
//         </button>
//         <button classNameName="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
//           <span classNameName="carousel-control-next-icon" aria-hidden="true"></span>
//           <span classNameName="visually-hidden">Next</span>
//         </button>
//       </div>
//     </div>
//   )
//   }
// }

// export default Content;


function Content() {
  return (
      <div>
          <div id="carouselExampleInterval" className="carousel slide" data-bs-ride="carousel">
              <div className="carousel-inner">
                  <div className="carousel-item active" data-bs-interval="10000">
                      <img src={img1} className="d-block w-100" alt="..."></img>
                  </div>
                  <div className="carousel-item" data-bs-interval="2000">
                      <img src={img2} className="d-block w-100" alt="..."></img>
                  </div>
                  <div className="carousel-item">
                      <img src={img3} className="d-block w-100" alt="..."></img>
                  </div>
              </div>
              <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
                  <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span className="visually-hidden">Previous</span>
              </button>
              <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
                  <span className="carousel-control-next-icon" aria-hidden="true"></span>
                  <span className="visually-hidden">Next</span>
              </button>
          </div>
      </div>
  )
}

export default Content
